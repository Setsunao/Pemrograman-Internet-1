-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 12 Jan 2021 pada 09.24
-- Versi Server: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_toko_online`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_keranjang`
--

CREATE TABLE `tbl_keranjang` (
  `id` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `jumlah_beli` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pesanan`
--

CREATE TABLE `tbl_pesanan` (
  `id` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `alamat` text NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `total` float NOT NULL,
  `status` enum('1','2','3','4') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_pesanan`
--

INSERT INTO `tbl_pesanan` (`id`, `id_produk`, `id_user`, `alamat`, `jumlah_beli`, `total`, `status`) VALUES
(4, 1, 4, 'Jl Raya Kebonrasi No 20 RT 003 RW 002 Kel Kebonsari Kec Sukun Kota Malang 65149', 1, 23000000, '2'),
(5, 2, 4, 'Jl Raya Kebonrasi No 20 RT 003 RW 002 Kel Kebonsari Kec Sukun Kota Malang 65149', 1, 8000000, '3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_produk`
--

CREATE TABLE `tbl_produk` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `harga` float NOT NULL,
  `gambar` text NOT NULL,
  `deskripsi` text NOT NULL,
  `stock` int(3) NOT NULL,
  `kategori` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_produk`
--

INSERT INTO `tbl_produk` (`id`, `nama`, `harga`, `gambar`, `deskripsi`, `stock`, `kategori`) VALUES
(1, 'DJI Phantom 4 Pro V2.0', 23000000, 'dji-phantom4.png', '1-inch 20MP Exmor R CMOS sensor, longer flight time and smarter features.', 29, 'Phantom'),
(2, 'DJI Phantom 3 Standart', 8000000, 'dji-phantom3.png', '0.3-inch 6MP Exmor R CMOS sensor, longer flight time and smarter features.', 22, 'Phantom'),
(17, 'DJI Phantom 2 Old', 13000000, 'phantom-2-c0f77edefa7396059f65c90b8c9e7647.png', '2MP Exmor R CMOS sensor, standart flight time and smarter features.', 0, 'Phantom'),
(19, 'Inspire 2', 18000000, '21491da847fa4e19ed8e8c8049586219.png', 'The Inspire 2 takes everything that was good improves it.CineCore2.0 has been upgraded to CineCore2.1', 14, 'Inspire'),
(20, 'Mavic 2 Enterprise', 38000000, 'mavic 2.png', 'Powerful Zoom Capability 12 MP 1/2.3â€ CMOS Sensor\r\nDynamic Zoom:2x Optical 3x Digital Zoom Capability\r\nPost Analysis Metadata:\r\nGPS Timestamping', 8, 'Enterprise'),
(21, 'Mavic 2 Enterprise Advanced', 46000000, 'dji-mavic-2-enterprise-advanced-drone-p7061-12438_image.jpg', 'Capture accurate details in any mission with the Mavic 2 Enterprise Advanced â€“ a highly versatile yet compact tool that packs a whole lot of performance upgrades. With high-resolution thermal and visual cameras', 6, 'Enterprise'),
(22, 'Agras T20', 130000000, '1dc1830b79cd4cb218f8ea29e74eca4d@374_374.png', 'Being a comprehensive spraying system, the T20 allows users to set flight and operation parameters easily. With a built-in RTK centimeter-level positioning system and RTK dongles,', 4, 'Ryze-Tech');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `nohp` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `level` enum('1','2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `nama`, `nohp`, `email`, `level`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Muhammad Ashraf Rafsanjani', '08983547754', 'akhikokayaba944@gmail.com', '1'),
(4, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'Dimas Pratama ', '089123823', 'samidz@gmail.com', '2'),
(5, 'user2', '7e58d63b60197ceb55a1c487989a3720', 'Qommaruddin Sifak', '0892382329', 'sifak@gmail.com', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_keranjang`
--
ALTER TABLE `tbl_keranjang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pesanan`
--
ALTER TABLE `tbl_pesanan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_produk`
--
ALTER TABLE `tbl_produk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_keranjang`
--
ALTER TABLE `tbl_keranjang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_pesanan`
--
ALTER TABLE `tbl_pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_produk`
--
ALTER TABLE `tbl_produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
