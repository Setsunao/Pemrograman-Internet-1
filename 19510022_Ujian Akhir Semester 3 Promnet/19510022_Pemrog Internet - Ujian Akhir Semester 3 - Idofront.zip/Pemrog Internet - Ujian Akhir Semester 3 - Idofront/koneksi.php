<?php

$koneksi = mysqli_connect('localhost', 'root', '', 'db_toko_online');

if (mysqli_connect_error()) {
    echo "Koneksi Database Gagal : " . mysqli_connect_error();
}

?>