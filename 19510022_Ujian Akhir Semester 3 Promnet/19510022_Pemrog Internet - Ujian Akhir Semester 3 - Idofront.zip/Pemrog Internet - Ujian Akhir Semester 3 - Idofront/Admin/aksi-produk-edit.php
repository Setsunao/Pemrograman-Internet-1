<?php 

    include '../koneksi.php';

    $id = $_POST['id'];
    $nama = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $deskripsi = $_POST['deskripsi'];
    $kategori = $_POST['kategori'];
    $stock = $_POST['stock'];
    
    $gambar = $_FILES['gambar']['name'];
    $file_tmp = $_FILES['gambar']['tmp_name'];

    if(!empty($_FILES['fileToUpload']['name'])){
        move_uploaded_file($file_tmp, '../uploads/Produk/'.$gambar);
        mysqli_query($koneksi, "UPDATE tbl_produk SET nama='$nama', harga='$harga', gambar='$gambar', deskripsi='$deskripsi', stock='$stock' , kategori='$kategori' WHERE id='$id'");
    }else{
        mysqli_query($koneksi, "UPDATE tbl_produk SET nama='$nama', harga='$harga', deskripsi='$deskripsi', stock='$stock' , kategori='$kategori' WHERE id='$id'");
    }
?>