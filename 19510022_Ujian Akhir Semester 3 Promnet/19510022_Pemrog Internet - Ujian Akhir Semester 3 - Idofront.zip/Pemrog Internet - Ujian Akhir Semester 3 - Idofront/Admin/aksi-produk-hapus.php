<?php

include '../koneksi.php';

$id_produk = $_POST['id'];

mysqli_query($koneksi, "DELETE FROM tbl_produk WHERE id='$id_produk'");