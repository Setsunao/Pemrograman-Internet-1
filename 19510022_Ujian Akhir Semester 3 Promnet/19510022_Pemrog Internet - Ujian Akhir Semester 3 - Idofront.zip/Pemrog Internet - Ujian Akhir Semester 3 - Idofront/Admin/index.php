<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Dashboard | Idofront</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="../public/images/favicon.ico">

    <!-- DataTables -->
    <link href="../public/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="../public/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />

    <!-- Responsive datatable examples -->
    <link href="../public/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />

    <?php include 'layouts/headerStyle.php'; ?>

    <?php include 'layouts/master.php';
    echo setLayout(); ?>

    <!-- Begin page -->
    <div id="layout-wrapper">
        <?php include 'layouts/topbar.php'; ?>

        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">
                    <!-- start page title -->

                    <?php
                    include '../koneksi.php';
                    $data_count = mysqli_query($koneksi, "SELECT (SELECT COUNT(id) FROM tbl_produk ) AS produk, (SELECT COUNT(id) FROM tbl_pesanan) AS pesanan, (SELECT COUNT(id) FROM tbl_user WHERE level=2) AS user");
                    $result = mysqli_fetch_array($data_count);
                    ?>

                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="page-title-box">
                                <h4 class="font-size-18">Pesanan</h4>
                                <ol class="breadcrumb mb-0">
                                    <li class="breadcrumb-item active">Selamat Datang Admin -
                                        <?php echo $_SESSION['nama']; ?></li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->
                    <div class="row">
                        <div class="col-xl-4 col-md-6">
                            <div class="card mini-stat bg-primary text-white">
                                <div class="card-body">
                                    <div class="mb-4">
                                        <div class="float-left mini-stat-img mr-4">
                                            <img src="../public/images/services-icon/03.png" alt="">
                                        </div>
                                        <h5 class="font-size-16 text-uppercase mt-0 text-white-50">Jumlah Produk</h5>
                                        <h4 class="font-weight-medium font-size-24"><?php echo $result['produk']; ?>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-6">
                            <div class="card mini-stat bg-primary text-white">
                                <div class="card-body">
                                    <div class="mb-4">
                                        <div class="float-left mini-stat-img mr-4">
                                            <img src="../public/images/services-icon/01.png" alt="">
                                        </div>
                                        <h5 class="font-size-16 text-uppercase mt-0 text-white-50">Jumlah Pesanan</h5>
                                        <h4 class="font-weight-medium font-size-24"><?php echo $result['pesanan']; ?>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-6">
                            <div class="card mini-stat bg-primary text-white">
                                <div class="card-body">
                                    <div class="mb-4">
                                        <div class="float-left mini-stat-img mr-4">
                                            <img src="../public/images/services-icon/02.png" alt="">
                                        </div>
                                        <h5 class="font-size-16 text-uppercase mt-0 text-white-50">Total Pelanggan</h5>
                                        <h4 class="font-weight-medium font-size-24"><?php echo $result['user']; ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end row -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body" id="pesanan-tampil">
                                    <h4 class="card-title mb-4">Transaksi Terbaru</h4>
                                    <table class="table table-hover table-centered mb-0">
                                        <thead>
                                            <tr>
                                                <th scope="col">No</th>
                                                <th scope="col">Nama Produk</th>
                                                <th scope="col">Pelanggan</th>
                                                <th scope="col" width="250px">Alamat</th>
                                                <th scope="col">Jumlah Beli</th>
                                                <th scope="col">Total</th>
                                                <th scope="col">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            include '../koneksi.php';
                                            $no = 1;
                                            $data = mysqli_query($koneksi, 'SELECT psn.id, prd.nama as nama_produk, usr.nama as nama_user, psn.alamat, psn.jumlah_beli, psn.total, psn.status FROM tbl_pesanan psn INNER JOIN tbl_produk prd ON psn.id_produk = prd.id INNER JOIN tbl_user usr ON psn.id_user = usr.id ORDER BY psn.id DESC LIMIT 6');

                                            while ($hasil = mysqli_fetch_array($data)) {
                                            ?>

                                                <tr>
                                                    <th scope="row"><?php echo $no++; ?></td>
                                                    <td><?php echo $hasil['nama_produk']; ?></td>
                                                    <td><?php echo $hasil['nama_user']; ?></td>
                                                    <td><?php echo $hasil['alamat']; ?></td>
                                                    <td><?php echo $hasil['jumlah_beli']; ?></td>
                                                    <td><?php echo $hasil['total']; ?></td>
                                                    <td><span class="badge badge-<?php
                                                                                    if ($hasil['status'] == '1') {
                                                                                        $status = 'Diproses';
                                                                                        echo 'primary';
                                                                                    } else if ($hasil['status'] == '2') {
                                                                                        $status = 'Diterima';
                                                                                        echo 'warning';
                                                                                    } else if ($hasil['status'] == '3') {
                                                                                        $status = 'Selesai';
                                                                                        echo 'success';
                                                                                    } else {
                                                                                        $status = 'Gagal';
                                                                                        echo 'danger';
                                                                                    }
                                                                                    ?>"><?php echo $status ?></span></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- end card -->
                        </div>

                    </div>
                    <!-- end row -->

                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->
            <?php include 'layouts/footer.php'; ?>
        </div>
        <!-- end main content-->
    </div>
    <!-- END layout-wrapper -->

    <?php include 'layouts/footerScript.php'; ?>

    <!-- Required datatable js -->
    <script src="../public/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../public/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <!-- Buttons examples -->
    <script src="../public/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../public/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="../public/libs/jszip/jszip.min.js"></script>
    <script src="../public/libs/pdfmake/build/pdfmake.min.js"></script>
    <script src="../public/libs/pdfmake/build/vfs_fonts.js"></script>
    <script src="../public/libs/datatables.net-buttons/js/buttons.php5.min.js"></script>
    <script src="../public/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../public/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <!-- Responsive examples -->
    <script src="../public/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../public/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
    <script src="../public/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js"></script>

    <!-- Datatable init js -->
    <script src="../public/js/pages/datatables.init.js"></script>
    <!-- <script src="../public/libs/jquery/jquery.min.js"></script> -->


    <?php include "layouts/content-end.php"; ?>