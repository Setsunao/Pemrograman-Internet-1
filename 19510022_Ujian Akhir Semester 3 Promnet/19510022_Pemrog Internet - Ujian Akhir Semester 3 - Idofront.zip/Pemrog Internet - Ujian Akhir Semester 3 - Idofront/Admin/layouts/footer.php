<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                © <?php echo date("Y"); ?> Idofront <span class="d-none d-sm-inline-block"> - @Muhammad Ashraf
                    Rafsanjani - 19510022 <i class="mdi mdi-heart text-danger"></i></span>
            </div>
        </div>
    </div>
</footer>