<h4 class="card-title mb-4">List Pesanan</h4>

<table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Produk</th>
            <th>Pelanggan</th>
            <th width="250px">Alamat</th>
            <th>Jumlah Beli</th>
            <th>Total</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>


    <tbody>

        <?php
        include '../koneksi.php';
        $no = 1;
        $data = mysqli_query($koneksi, 'SELECT psn.id, prd.nama as nama_produk, usr.nama as nama_user, psn.alamat, psn.jumlah_beli, psn.total, psn.status FROM tbl_pesanan psn INNER JOIN tbl_produk prd ON psn.id_produk = prd.id INNER JOIN tbl_user usr ON psn.id_user = usr.id;');

        while ($hasil = mysqli_fetch_array($data)) {
        ?>

            <tr>
                <td><?php echo $no++; ?></td>
                <td><?php echo $hasil['nama_produk']; ?></td>
                <td><?php echo $hasil['nama_user']; ?></td>
                <td><?php echo $hasil['alamat']; ?></td>
                <td><?php echo $hasil['jumlah_beli']; ?></td>
                <td><?php echo $hasil['total']; ?></td>
                <td><span class="badge badge-<?php
                                                if ($hasil['status'] == '1') {
                                                    $status = 'Diproses';
                                                    echo 'primary';
                                                } else if ($hasil['status'] == '2') {
                                                    $status = 'Diterima';
                                                    echo 'warning';
                                                } else if ($hasil['status'] == '3') {
                                                    $status = 'Selesai';
                                                    echo 'success';
                                                } else {
                                                    $status = 'Gagal';
                                                    echo 'danger';
                                                }
                                                ?>"><?php echo $status ?></span></td>
                <td>
                    <div>
                        <a href="#" class="btn btn-warning btn-sm pesanan-edit" value="<?php echo $hasil['id']; ?>" data-toggle="modal" data-target=".modal-edit-pesanan">Edit</a>
                    </div>
                </td>
            </tr>

        <?php } ?>

    </tbody>
</table>