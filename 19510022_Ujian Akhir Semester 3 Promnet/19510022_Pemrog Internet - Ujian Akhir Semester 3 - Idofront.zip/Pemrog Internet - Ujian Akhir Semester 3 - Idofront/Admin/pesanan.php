<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Dashboard | Idofront</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="../public/images/favicon.ico">

    <!-- DataTables -->
    <link href="../public/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="../public/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet"
        type="text/css" />

    <!-- Responsive datatable examples -->
    <link href="../public/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet"
        type="text/css" />

    <?php include 'layouts/headerStyle.php'; ?>

    <?php include 'layouts/master.php'; echo setLayout();?>

    <!-- Begin page -->
    <div id="layout-wrapper">
        <?php include 'layouts/topbar.php'; ?>

        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">
                    <!-- start page title -->
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="page-title-box">
                                <h4 class="font-size-18">Pesanan</h4>
                                <ol class="breadcrumb mb-0">
                                    <li class="breadcrumb-item active">Selamat Datang Admin -
                                        <?php echo $_SESSION['nama']; ?></li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="modal fade modal-edit-pesanan" tabindex="-1" role="dialog"
                        aria-labelledby="modal-edit-pesanan" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <form id="pesanan-edit-data" class="custom-validation" method="POST"
                                    enctype="multipart/form-data">
                                    <div class="modal-header">
                                        <h5 class="modal-title mt-0" id="modal-edit-pesanan">Edit Pesanan</h5>
                                        <button type="button" class="close" data-dismiss="modal"
                                            aria-hidden="true">×</button>
                                    </div>
                                    <div class="modal-body" id="form-edit-pesanan">

                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-primary waves-effect" data-dismiss="modal"
                                            aria-hidden="true">
                                            Cancel
                                        </button>
                                        <button type="submit" class="btn btn-success waves-effect waves-light mr-1">
                                            Submit
                                        </button>
                                    </div>
                                </form>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body" id="pesanan-tampil">

                                </div>
                            </div>
                            <!-- end card -->
                        </div>

                    </div>
                    <!-- end row -->

                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->
            <?php include 'layouts/footer.php'; ?>
        </div>
        <!-- end main content-->
    </div>
    <!-- END layout-wrapper -->

    <?php include 'layouts/footerScript.php'; ?>

    <!-- Required datatable js -->
    <script src="../public/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../public/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <!-- Buttons examples -->
    <script src="../public/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="../public/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="../public/libs/jszip/jszip.min.js"></script>
    <script src="../public/libs/pdfmake/build/pdfmake.min.js"></script>
    <script src="../public/libs/pdfmake/build/vfs_fonts.js"></script>
    <script src="../public/libs/datatables.net-buttons/js/buttons.php5.min.js"></script>
    <script src="../public/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="../public/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <!-- Responsive examples -->
    <script src="../public/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="../public/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
    <script src="../public/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js"></script>

    <!-- Datatable init js -->
    <script src="../public/js/pages/datatables.init.js"></script>
    <!-- <script src="../public/libs/jquery/jquery.min.js"></script> -->


    <?php include "layouts/content-end.php"; ?>
    <script>
    $(document).ready(function() {
        tampilData();

        $(document).on('click', '.pesanan-edit', function(e) {
            e.preventDefault();
            $.post('pesanan-edit.php', {
                    id: $(this).attr('value')
                },
                function(html) {
                    $("#form-edit-pesanan").html(html);
                }
            );
        });

        $("#pesanan-edit-data").on("submit", function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            $.ajax({
                url: 'aksi-pesanan-edit.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(data) {
                    $('.modal-edit-pesanan').modal('hide');
                    tampilData();
                }
            });
        });

    });

    function tampilData() {
        $.ajax({
            url: 'pesanan-tampil.php',
            type: 'get',
            success: function(data) {
                $('#pesanan-tampil').html(data);
            }
        });
    }
    </script>