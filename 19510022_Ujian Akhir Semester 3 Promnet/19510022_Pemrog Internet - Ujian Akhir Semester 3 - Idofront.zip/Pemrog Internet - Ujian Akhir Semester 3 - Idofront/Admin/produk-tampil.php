<h4 class="card-title mb-4">List Produk</h4>

<table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
    <thead>
        <tr>
            <th>No</th>
            <th width="100px">Gambar</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th width="200px">Deskripsi</th>
            <th>Kategori</th>
            <th>Stock</th>
            <th colspan="2">Aksi</th>
        </tr>
    </thead>


    <tbody>

        <?php
        include '../koneksi.php';
        $no = 1;
        $data = mysqli_query($koneksi, 'SELECT * FROM tbl_produk');

        while ($hasil = mysqli_fetch_array($data)) {
        ?>

            <tr>
                <td><?php echo $no++; ?></td>
                <td><img src="<?php echo '../uploads/Produk/' . $hasil['gambar']; ?>" class='img-fluid' /></td>
                <td><?php echo $hasil['nama']; ?></td>
                <td><?php echo $hasil['harga']; ?></td>
                <td><?php echo $hasil['deskripsi']; ?></td>
                <td><?php echo $hasil['stock']; ?></td>
                <td><span class="badge badge-<?php
                                                if ($hasil['kategori'] == 'Phantom') {
                                                    echo 'danger';
                                                } else if ($hasil['kategori'] == 'Inspire') {
                                                    echo 'success';
                                                } else if ($hasil['kategori'] == 'Enterprise') {
                                                    echo 'warning';
                                                } else {
                                                    echo 'primary';
                                                }
                                                ?>"><?php echo $hasil['kategori']; ?></span></td>
                <td>
                    <div>
                        <a href="#" class="btn btn-warning btn-sm produk-edit" value="<?php echo $hasil['id']; ?>" data-toggle="modal" data-target=".modal-edit-produk">Edit</a>
                        <a href="#" class="btn btn-danger btn-sm produk-hapus" value="<?php echo $hasil['id']; ?>">Hapus</a>
                    </div>
                </td>
            </tr>

        <?php } ?>

    </tbody>
</table>