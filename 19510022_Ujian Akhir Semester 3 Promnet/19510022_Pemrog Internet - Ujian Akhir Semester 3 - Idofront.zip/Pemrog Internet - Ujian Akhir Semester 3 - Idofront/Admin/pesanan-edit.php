<?php

include "../koneksi.php";
$id = $_POST['id'];
$data = mysqli_query($koneksi, "SELECT psn.id, prd.nama as nama_produk, usr.nama as nama_user, psn.alamat, psn.jumlah_beli, psn.total, psn.status FROM tbl_pesanan psn INNER JOIN tbl_produk prd ON psn.id_produk = prd.id INNER JOIN tbl_user usr ON psn.id_user = usr.id WHERE psn.id='$id'");
$hasil = mysqli_fetch_array($data);
?>

<div class="form-group">
    <label>Nama Produk</label>
    <input type="hidden" name="id" class="form-control" value="<?php echo $hasil['id']; ?>" required />
    <input type="text" name="nama_produk" class="form-control" value="<?php echo $hasil['nama_produk']; ?>" required disabled />
</div>

<div class="form-group">
    <label>Nama Pelanggan</label>
    <input type="text" name="nama_user" class="form-control" value="<?php echo $hasil['nama_user']; ?>" required disabled />
</div>

<div class="form-group">
    <label>Alamat</label>
    <textarea class="form-control" name="alamat" rows="5" required disabled><?php echo $hasil['alamat']; ?></textarea>
</div>

<div class="form-row">
    <div class="col-6 mb-3">
        <label>Jumlah Beli</label>
        <input type="number" name="jumlah_beli" class="form-control" value="<?php echo $hasil['jumlah_beli']; ?>" required disabled />
    </div>
    <div class="col-6 mb-3">
        <label>Total</label>
        <input type="number" name="total" class="form-control" value="<?php echo $hasil['total']; ?>" required disabled />
    </div>
</div>
<div class="form-group">
    <label>Status</label>
    <select class="form-control" name="status" required>
        <option value='1' <?php if ($hasil['status'] == "1") echo 'selected'; ?>>Diproses</option>
        <option value='2' <?php if ($hasil['status'] == "2") echo 'selected'; ?>>Diterima</option>
        <option value='3' <?php if ($hasil['status'] == "3") echo 'selected'; ?>>Selesai
        </option>
        <option value='4' <?php if ($hasil['status'] == "4") echo 'selected'; ?>>Gagal</option>
    </select>
</div>