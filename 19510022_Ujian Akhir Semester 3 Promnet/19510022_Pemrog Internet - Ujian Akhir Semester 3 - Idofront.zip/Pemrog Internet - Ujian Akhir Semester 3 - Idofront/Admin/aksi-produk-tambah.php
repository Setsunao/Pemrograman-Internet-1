<?php

include '../koneksi.php';

$nama = $_POST['nama_produk'];
$harga = $_POST['harga'];
$deskripsi = $_POST['deskripsi'];
$kategori = $_POST['kategori'];
$stock = $_POST['stock'];


$gambar = $_FILES['gambar']['name'];
$file_tmp = $_FILES['gambar']['tmp_name'];

move_uploaded_file($file_tmp, '../uploads/Produk/'.$gambar);

mysqli_query($koneksi, "INSERT INTO tbl_produk VALUES(NULL, '$nama', $harga, '$gambar', '$deskripsi', $stock, '$kategori')");