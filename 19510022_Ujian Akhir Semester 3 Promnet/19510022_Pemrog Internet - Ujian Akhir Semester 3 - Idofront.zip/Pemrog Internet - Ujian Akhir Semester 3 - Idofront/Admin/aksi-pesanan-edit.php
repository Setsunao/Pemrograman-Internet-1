<?php 

    include '../koneksi.php';

    $id = $_POST['id'];
    $status = $_POST['status'];

    mysqli_query($koneksi, "UPDATE tbl_pesanan SET status='$status' WHERE id='$id'");

?>