<?php
session_start();
if ($_SESSION['status'] != 'login') {
    header('location:../login.php?pesan=belum_login');
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Idofront | Keranjang Belanja</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="public/images/favicon.ico">

    <?php include 'User/layouts/headerStyle.php'; ?>

    <?php include 'User/layouts/master.php';
    echo setLayout(); ?>

    <!-- Begin page -->
    <div id="layout-wrapper" style="background-color: #eaeaea;">
        <?php include 'User/layouts/topbar.php'; ?>
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="page-title-box">
                                <h4 class="font-size-18">Keranjang Belanja</h4>
                                <ol class="breadcrumb mb-0">
                                    <li class="breadcrumb-item active"></li>
                                </ol>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade modal-checkout" tabindex="-1" role="dialog" aria-labelledby="modal-checkout" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <form id="pesanan-edit-data" class="custom-validation" method="POST" enctype="multipart/form-data">
                                    <div class="modal-header">
                                        <h5 class="modal-title mt-0" id="modal-checkout">Checkout</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                    </div>
                                    <div class="modal-body" id="form-checkout">
                                        <div class="form-group">
                                            <label>Alamat Lengkap</label>
                                            <textarea class="form-control" name="alamat" rows="5" required></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="reset" class="btn btn-primary waves-effect" data-dismiss="modal" aria-hidden="true">
                                            Cancel
                                        </button>
                                        <button type="submit" class="btn btn-success waves-effect waves-light mr-1">
                                            Checkout
                                        </button>
                                    </div>
                                </form>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->


                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body" id="keranjang-tampil">

                                </div>
                                <!-- end card -->
                            </div>
                        </div>
                    </div>
                </div> <!-- container-fluid -->
            </div>
        </div>
        <!-- End Page-content -->
        <?php include 'User/layouts/footer.php'; ?>
    </div>
    <?php include 'User/layouts/rightbar.php'; ?>
    <?php include 'User/layouts/footerScript.php'; ?>

    <!-- Peity chart-->
    <script src="public/libs/peity/jquery.peity.min.js"></script>
    <!-- Plugin Js-->
    <script src="public/js/pages/dashboard.init.js"></script>
    <?php include 'User/layouts/content-end.php'; ?>
    <script>
        $(document).ready(function() {
            tampilKeranjang();
            tampilData();

            $("#pesanan-edit-data").on("submit", function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                $.ajax({
                    url: 'User/aksi-checkout.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(data) {
                        $('.modal-checkout').modal('hide');
                        tampilKeranjang();
                        tampilData();
                    }
                });
            });

            $(document).on("click", ".keranjang-hapus", function() {
                var id = $(this).attr("value");
                $.ajax({
                    url: 'User/aksi-keranjang-hapus.php',
                    type: 'post',
                    data: {
                        id: id
                    },
                    success: function(data) {
                        tampilData();
                        tampilKeranjang();
                    }
                });
            });

        });

        function tampilKeranjang() {
            $.ajax({
                url: 'User/produk-tampil-keranjang.php',
                type: 'get',
                success: function(data) {
                    $('#produk-tampil-keranjang').html(data);
                }
            });
        }

        function tampilData() {
            $.ajax({
                url: 'User/keranjang-tampil.php',
                type: 'get',
                success: function(data) {
                    $('#keranjang-tampil').html(data);
                }
            });
        }
    </script>