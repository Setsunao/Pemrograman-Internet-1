<?php

    session_start();
    include 'koneksi.php';

    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $data = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username='$username' AND password='$password'");
    $cek = mysqli_num_rows($data);
    $result = mysqli_fetch_array($data);

    if($cek > 0){
        $_SESSION['username'] = $username;
        $_SESSION['nama'] = $result['nama'];
        $_SESSION['status'] = 'login';
        
        if($result['level'] == '1'){
            $_SESSION['level'] = '1';
            header('location:Admin/index.php');            
        }
        else if($result['level'] == '2'){
            $_SESSION['level'] = '2';
            $_SESSION['userid'] = $result['id'];
            header('location:index.php');            
        }
    }else{
        header("location:login.php?pesan=gagal");
    }
