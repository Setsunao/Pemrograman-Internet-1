<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Idofront | Drone Shop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="public/images/favicon.ico">

    <style>
        #produk-tampil .card img {
            vertical-align: middle;
            border-style: none;
            width: 100%;
            max-width: 350px;
            height: 250px;
            object-fit: cover;
            padding: 30px;
        }
    </style>

    <?php include 'User/layouts/headerStyle.php'; ?>

    <?php include 'User/layouts/master.php';
    echo setLayout(); ?>

    <!-- Begin page -->
    <div id="layout-wrapper" style="background-color: #eaeaea;">
        <?php include 'User/layouts/topbar.php'; ?>
        <div class="main-content">

            <div class="page-content mx-0 px-0">
                <div id="carouselExampleCaption" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner" role="listbox">
                        <div class="carousel-item active">
                            <img src="public/images/img-2.jpg" alt="..." class="d-block img-fluid" style="min-height: 550px;">
                            <div class="carousel-caption d-none d-md-block text-white" style="background-color: #00000040;">
                                <h5>Mavic 2 Enterprise Advanced</h5>
                                <p>Dual Iamging Reimagined.</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="public/images/img-1.jpg" alt="..." class="d-block img-fluid" style="min-height: 550px;">
                            <div class="carousel-caption d-none d-md-block text-white" style="background-color: #00000040;">
                                <h5>DJI Mini 2</h5>
                                <p>Make Your Moments Fly.</p>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img src="public/images/img-3.jpg" alt="..." class="d-block img-fluid" style="min-height: 550px;">
                            <div class="carousel-caption d-none d-md-block text-white" style="background-color: #00000040;">
                                <h5>Agras T20</h5>
                                <p>Intelligent and Powerful.</p>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleCaption" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleCaption" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
                <div class="container-fluid">

                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="page-title-box">
                                <h4 class="font-size-18">Newest Product</h4>
                                <ol class="breadcrumb mb-0">
                                    <li class="breadcrumb-item active">The Future Of Possible</li>
                                </ol>
                            </div>
                        </div>

                        <div class="row" id="produk-tampil">

                        </div>

                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->
                <?php include 'User/layouts/footer.php'; ?>
            </div>
            <?php include 'User/layouts/rightbar.php'; ?>
            <?php include 'User/layouts/footerScript.php'; ?>

            <!-- Peity chart-->
            <script src="public/libs/peity/jquery.peity.min.js"></script>
            <!-- Plugin Js-->
            <script src="public/js/pages/dashboard.init.js"></script>
            <?php include 'User/layouts/content-end.php'; ?>
            <script>
                $(document).ready(function() {
                    tampilKeranjang();
                    tampilData();

                    $(document).on('click', '.produk-tambah-keranjang', function(e) {
                        e.preventDefault();
                        var id = $(this).attr('value');
                        $.ajax({
                            url: 'User/aksi-produk-keranjang.php',
                            type: 'POST',
                            data: {
                                id: id,
                            },
                            success: function(data) {
                                tampilData();
                                tampilKeranjang();
                            }
                        });

                    });

                });

                function tampilKeranjang() {
                    $.ajax({
                        url: 'User/produk-tampil-keranjang.php',
                        type: 'get',
                        success: function(data) {
                            $('#produk-tampil-keranjang').html(data);
                        }
                    });
                }

                function tampilData() {
                    $.ajax({
                        url: 'User/produk-tampil.php',
                        type: 'get',
                        success: function(data) {
                            $('#produk-tampil').html(data);
                        }
                    });
                }
            </script>