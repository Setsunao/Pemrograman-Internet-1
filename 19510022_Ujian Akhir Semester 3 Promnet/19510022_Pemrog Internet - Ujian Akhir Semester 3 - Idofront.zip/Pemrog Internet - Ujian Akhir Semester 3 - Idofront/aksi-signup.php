<?php

    session_start();
    include 'koneksi.php';

    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $nama = $_POST['nama'];
    $nohp = $_POST['nohp'];
    $email = $_POST['email'];

    $data = mysqli_query($koneksi, "SELECT * FROM tbl_user WHERE username='$username'");
    $cek = mysqli_num_rows($data);

    if($cek > 0){
        header("location:signup.php?pesan=duplicate");           
    }else{
        mysqli_query($koneksi, "INSERT INTO tbl_user VALUES(NULL, '$username', '$password', '$nama', '$nohp', '$email', '2') ");
        header('location:login.php?pesan=berhasil_daftar'); 
    }

?>