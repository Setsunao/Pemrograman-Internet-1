<?php
session_start();
if ($_SESSION['status'] != 'login') {
    header('location:../login.php?pesan=belum_login');
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Idofront | Transaksi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="public/images/favicon.ico">

    <?php include 'User/layouts/headerStyle.php'; ?>

    <?php include 'User/layouts/master.php';
    echo setLayout(); ?>

    <!-- Begin page -->
    <div id="layout-wrapper" style="background-color: #eaeaea;">
        <?php include 'User/layouts/topbar.php'; ?>
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="page-title-box">
                                <h4 class="font-size-18">Daftar Transaksi</h4>
                                <ol class="breadcrumb mb-0">
                                    <li class="breadcrumb-item active"></li>
                                </ol>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body" id="pesanan-tampil">

                                </div>
                                <!-- end card -->
                            </div>
                        </div>
                    </div>
                </div> <!-- container-fluid -->
            </div>
        </div>
        <!-- End Page-content -->
        <?php include 'User/layouts/footer.php'; ?>
    </div>
    <?php include 'User/layouts/rightbar.php'; ?>
    <?php include 'User/layouts/footerScript.php'; ?>

    <!-- Peity chart-->
    <script src="public/libs/peity/jquery.peity.min.js"></script>
    <!-- Plugin Js-->
    <script src="public/js/pages/dashboard.init.js"></script>
    <?php include 'User/layouts/content-end.php'; ?>
    <script>
        $(document).ready(function() {
            tampilKeranjang();
            tampilData();

        });

        function tampilKeranjang() {
            $.ajax({
                url: 'User/produk-tampil-keranjang.php',
                type: 'get',
                success: function(data) {
                    $('#produk-tampil-keranjang').html(data);
                }
            });

            $(document).on("click", ".pesanan-selesai", function() {
                var id = $(this).attr("value");
                $.ajax({
                    url: 'User/aksi-pesanan-selesai.php',
                    type: 'post',
                    data: {
                        id: id
                    },
                    success: function(data) {
                        tampilData();
                        tampilKeranjang();
                    }
                });
            });

        }

        function tampilData() {
            $.ajax({
                url: 'User/pesanan-tampil.php',
                type: 'get',
                success: function(data) {
                    $('#pesanan-tampil').html(data);
                }
            });
        }
    </script>