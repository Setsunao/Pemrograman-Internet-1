<?php
session_start();
include '../koneksi.php';
$data = mysqli_query($koneksi, 'SELECT * FROM tbl_produk');

while ($hasil = mysqli_fetch_array($data)) {
?>

<div class="col-md-6 col-lg-6 col-xl-3">
    <div class="card">
        <img class="card-img-top img-fluid" src="uploads/produk/<?php echo $hasil['gambar']; ?>" alt="product-img">
        <div class="card-body">
            <h4 class="card-title  mt-0"><?php echo $hasil['nama']; ?></h4>
            <p class="card-text">Rp. <?php echo number_format($hasil['harga'], 2, ',', '.'); ?></p>
            <?php
                if (@$_SESSION['status'] == 'login') {
                    if ($hasil['stock'] < 1) {
                        echo '<button class="btn btn-warning waves-effect waves-light " disabled>Stock Habis</button>';
                    } else {
                        echo '<a href="#" class="btn btn-primary waves-effect waves-light produk-tambah-keranjang" value=' . $hasil['id'] . '>Tambah Ke Keranjang</a>';
                    }
                } else {
                    if ($hasil['stock'] < 1) {
                        echo '<button class="btn btn-warning waves-effect waves-light " disabled>Stock Habis</button>';
                    } else {
                        echo '<a href="login.php" class="btn btn-danger waves-effect waves-light" >Login untuk beli</a>';
                    }
                }
                ?>
        </div>
    </div>
</div>

<?php } ?>