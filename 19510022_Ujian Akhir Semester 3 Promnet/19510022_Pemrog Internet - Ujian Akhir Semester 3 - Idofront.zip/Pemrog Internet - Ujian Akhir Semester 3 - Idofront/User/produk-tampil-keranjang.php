<?php
include '../koneksi.php';
session_start();
@$id = $_SESSION['userid'];
$data = mysqli_query($koneksi, "SELECT SUM(jumlah_beli) as jumlah FROM tbl_keranjang WHERE id_user='$id' ");

$hasil = mysqli_fetch_array($data);
?>
<i class="mdi mdi-cart"></i>
<span class="badge badge-danger badge-pill"><?php echo $hasil['jumlah']; ?></span>