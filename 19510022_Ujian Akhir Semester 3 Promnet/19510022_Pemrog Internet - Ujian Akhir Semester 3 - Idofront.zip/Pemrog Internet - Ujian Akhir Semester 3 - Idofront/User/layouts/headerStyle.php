   <!-- Bootstrap Css -->
   <!-- -->
   <link href="public/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
   <link href="" id="bootstrap-style" rel="stylesheet" type="text/css" />
   <!-- Icons Css -->
   <link href="public/css/icons.min.css" rel="stylesheet" type="text/css" />
   <!-- App Css-->
   <link href="public/css/app.min.css" rel="stylesheet" type="text/css" />
   <link href="" id="app-style" rel="stylesheet" type="text/css" />
   </head>