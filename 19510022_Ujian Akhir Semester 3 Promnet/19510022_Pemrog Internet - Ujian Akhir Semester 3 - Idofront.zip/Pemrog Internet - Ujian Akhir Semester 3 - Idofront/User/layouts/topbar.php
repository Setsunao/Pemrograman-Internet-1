<?php
@session_start();
?>
<header id="page-topbar">
    <div class="navbar-header">
        <div class="d-flex">
            <!-- LOGO -->
            <div class="navbar-brand-box">
                <a href="index.php" class="logo logo-dark">
                    <span class="logo-sm">
                        <img src="public/images/logo.svg" alt="" height="22">
                    </span>
                    <span class="logo-lg">
                        <img src="public/images/logo-dark.png" alt="" height="17">
                    </span>
                </a>

                <a href="index.php" class="logo logo-light">
                    <span class="logo-sm">
                        <img src="public/images/logo-sm.png" alt="" height="22">
                    </span>
                    <span class="logo-lg">
                        <img src="public/images/logo-light.png" alt="" height="18">
                    </span>
                </a>
            </div>

            <button type="button" class="btn btn-sm mr-2 font-size-24 d-lg-none header-item waves-effect waves-light"
                data-toggle="collapse" data-target="#topnav-menu-content">
                <i class="mdi mdi-menu"></i>
            </button>

        </div>

        <div class="d-flex">

            <!-- App Search-->

            <div class="dropdown d-none d-lg-inline-block">
                <button type="button" class="btn header-item noti-icon waves-effect" data-toggle="fullscreen">
                    <i class="mdi mdi-fullscreen"></i>
                </button>
            </div>


            <?php
            if (@$_SESSION['status'] == 'login') {
                echo '<div class="dropdown d-none d-lg-inline-block">
                        <a href="keranjang.php">
                            <button type="button" id="produk-tampil-keranjang" class="btn header-item noti-icon waves-effect">
                            </button>
                        </a>
                    </div>';
            } else {
                echo '<div class="dropdown d-none d-lg-inline-block">
                        <a href="login.php">
                            <button type="button" id="produk-tampil-keranjang" class="btn header-item noti-icon waves-effect">
                            </button>
                        </a>
                    </div>';
            } ?>



            <div class="dropdown d-inline-block">
                <button type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img class="rounded-circle header-profile-user" src="public/images/profile.jpg" alt="Header Avatar">
                </button>
                <div class="dropdown-menu dropdown-menu-right">
                    <!-- item-->
                    <?php
                    if (@$_SESSION['status'] != 'login') {
                        echo '<a class="dropdown-item text-danger" href="login.php"><i class="bx bx-power-off font-size-17 align-middle mr-1 text-primary"></i> Login</a>';
                    } else {
                        echo '<a class="dropdown-item text-danger" href="aksi-logout.php"><i class="bx bx-power-off font-size-17 align-middle mr-1 text-danger"></i> Logout</a>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- sidebar -->
<div class="topnav" style="z-index: 99;">
    <div class="container-fluid">
        <nav class="navbar navbar-light navbar-expand-lg topnav-menu">

            <div class="collapse navbar-collapse" id="topnav-menu-content">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="ti-home mr-2"></i>Dashboard
                        </a>
                    </li>

                    <?php
                    if (@$_SESSION['status'] == 'login') {
                        echo '<li class="nav-item">
                                <a class="nav-link" href="keranjang.php">
                                    <i class="ti-shopping-cart mr-2"></i>Keranjang
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="pesanan.php">
                                    <i class="ti-receipt mr-2"></i>Transaksi
                                </a>
                            </li>';
                    } ?>
                </ul>
            </div>
        </nav>
    </div>
</div>