<?php 

    include '../koneksi.php';

    $id = $_POST['id'];

    mysqli_query($koneksi, "UPDATE tbl_pesanan SET status='3' WHERE id='$id'");
