<table class="table table-hover table-centered table-nowrap mb-0">
    <thead>
        <tr>
            <th scope="col">No</th>
            <th scope="col" width="100px">Gambar</th>
            <th scope="col">Nama Produk</th>
            <th scope="col">Harga Satuan</th>
            <th scope="col">Jumlah Beli</th>
            <th scope="col">Harga</th>
            <th scope="col">Update</th>
        </tr>
    </thead>
    <tbody>
        <?php
        session_start();
        include '../koneksi.php';
        $no = 1;
        $total = 0;
        $userid = $_SESSION['userid'];
        $data = mysqli_query($koneksi, "SELECT krj.id, prd.gambar, prd.nama as nama_produk, prd.harga, krj.jumlah_beli, (prd.harga*krj.jumlah_beli) as total FROM tbl_keranjang krj INNER JOIN tbl_produk prd ON krj.id_produk = prd.id INNER JOIN tbl_user usr ON krj.id_user = usr.id WHERE krj.id_user = $userid");

        if (mysqli_num_rows($data) > 0) {
            while ($hasil = mysqli_fetch_array($data)) {
                $total = $total + $hasil['total'];
        ?>
        <tr>
            <th scope="row"><?php echo $no++; ?></td>
            <td><img src="<?php echo 'uploads/Produk/' . $hasil['gambar']; ?>" class='img-fluid' /></td>
            <td><?php echo $hasil['nama_produk']; ?></td>
            <td>Rp. <?php echo number_format($hasil['harga'], 2, ',', '.'); ?></td>
            <td><?php echo $hasil['jumlah_beli']; ?></td>
            <td>Rp. <?php echo number_format($hasil['total'], 2, ',', '.'); ?></td>
            <td><a href="#" class="btn btn-danger btn-sm keranjang-hapus" value="<?php echo $hasil['id']; ?>">Hapus</a>
            </td>
        </tr>
        <?php }
        } else {
            echo '<tr><td colspan="7"> Belum ada produk dalam keranjang belanja..</td></tr>';
        } ?>
        <tr>
            <td colspan="7"></td>
        </tr>
        <tr>
            <td class='font-weight-bold text-right h4' colspan='5'></td>
            <td class='h4 text-right' colspan="2"><span class="font-weight-normal">Total Harga &nbsp;&nbsp;</span> Rp.
                <?php echo number_format($total, 2, ',', '.'); ?></td>
        </tr>
        <tr>
            <td class='font-weight-bold' colspan='5'></td>
            <td class='text-right h4' colspan="2">
                <?php
                if (mysqli_num_rows($data) > 0) {
                    echo '<button type="button" class="btn btn-success waves-effect waves-light pesanan-edit" data-toggle="modal" data-target=".modal-checkout" value=' . $_SESSION['userid'] . '>Checkout</button>';
                } else {
                    echo '<button type="button" class="btn btn-success waves-effect waves-light" disabled>Checkout</button>';
                } ?>


            </td>
        </tr>
    </tbody>
</table>