<?php

include '../koneksi.php';
session_start();

$id_produk = $_POST['id'];
$id_user = $_SESSION['userid'];

$getproduk = mysqli_query($koneksi, "SELECT * FROM tbl_produk WHERE id='$id_produk'");
$resproduk = mysqli_fetch_array($getproduk);
if ($resproduk['stock'] > 0) {
    $stock = $resproduk['stock'] - 1;
    mysqli_query($koneksi, "UPDATE tbl_produk SET stock='$stock' WHERE id='$id_produk' ");
    $data = mysqli_query($koneksi, "SELECT * FROM tbl_keranjang WHERE id_produk='$id_produk' AND id_user='$id_user' ");

    if (mysqli_num_rows($data) > 0) {
        $result = mysqli_fetch_array($data);
        $jumlah_beli = $result['jumlah_beli'] + 1;
        mysqli_query($koneksi, "UPDATE tbl_keranjang SET jumlah_beli='$jumlah_beli' WHERE id_produk='$id_produk' AND id_user='$id_user' ");
    } else {
        mysqli_query($koneksi, "INSERT INTO tbl_keranjang VALUES(NULL, $id_produk, $id_user, 1)");
    }
}
