<?php

include '../koneksi.php';

$id = $_POST['id'];

$data = mysqli_query($koneksi, "SELECT * FROM tbl_keranjang WHERE id='$id'");
$hasil = mysqli_fetch_array($data);
$id_produk = $hasil['id_produk'];

$dataproduk = mysqli_query($koneksi, "SELECT * FROM tbl_produk WHERE id='$id_produk'");
$result = mysqli_fetch_array($dataproduk);

$stock = $result['stock'] + $hasil['jumlah_beli'];

mysqli_query($koneksi, "UPDATE tbl_produk SET stock='$stock' WHERE id='$id_produk'");
mysqli_query($koneksi, "DELETE FROM tbl_keranjang WHERE id='$id'");
