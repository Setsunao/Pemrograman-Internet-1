<?php
session_start();
include '../koneksi.php';

$userid = $_SESSION['userid'];
$alamat = $_POST['alamat'];

$data = mysqli_query($koneksi, "SELECT krj.id, prd.id as id_produk, prd.harga, krj.jumlah_beli, (prd.harga*krj.jumlah_beli) as total FROM tbl_keranjang krj INNER JOIN tbl_produk prd ON krj.id_produk = prd.id INNER JOIN tbl_user usr ON krj.id_user = usr.id WHERE krj.id_user = $userid");
while ($hasil = mysqli_fetch_array($data)) {

    $id_keranjang = $hasil['id'];
    $id_produk = $hasil['id_produk'];
    $jumlah_beli = $hasil['jumlah_beli'];
    $total = $hasil['total'];

    mysqli_query($koneksi, "INSERT INTO tbl_pesanan VALUES(null, $id_produk, $userid, '$alamat', $jumlah_beli, $total, '1') ");
    mysqli_query($koneksi, "DELETE FROM tbl_keranjang WHERE id='$id_keranjang' ");
}
