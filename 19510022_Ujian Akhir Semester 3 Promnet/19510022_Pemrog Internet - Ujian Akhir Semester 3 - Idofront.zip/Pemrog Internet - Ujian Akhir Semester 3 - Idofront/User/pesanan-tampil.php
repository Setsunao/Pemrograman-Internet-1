<table class="table table-hover table-centered mb-0">
    <thead>
        <tr>
            <th scope="col">No</th>
            <th scope="col">Nama Produk</th>
            <th scope="col" style="width: 250px !important;">Alamat</th>
            <th scope="col">Jumlah Beli</th>
            <th scope="col">Total</th>
            <th scope="col">Status</th>
            <th scope="col">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        session_start();
        include '../koneksi.php';
        $no = 1;
        $userid = $_SESSION['userid'];
        $data = mysqli_query($koneksi, "SELECT psn.id, prd.nama, psn.alamat, psn.jumlah_beli, psn.total, psn.status FROM tbl_pesanan psn INNER JOIN tbl_produk prd ON psn.id_produk = prd.id INNER JOIN tbl_user usr ON psn.id_user = usr.id WHERE psn.id_user = $userid");

        if (mysqli_num_rows($data) > 0) {
            while ($hasil = mysqli_fetch_array($data)) {
        ?>
        <tr>
            <th scope="row"><?php echo $no++; ?></td>
            <td><?php echo $hasil['nama']; ?></td>
            <td><?php echo $hasil['alamat']; ?></td>
            <td><?php echo $hasil['jumlah_beli']; ?></td>
            <td><?php echo number_format($hasil['total'], 2, ',', '.'); ?></td>
            <td><span class="badge 
                    <?php
                    if ($hasil['status'] == '1') {
                        $status = 'Diproses';
                        echo 'badge-primary';
                    } else if ($hasil['status'] == '2') {
                        $status = 'Diterima';
                        echo 'badge-warning';
                    } else if ($hasil['status'] == '3') {
                        $status = 'Selesai';
                        echo 'badge-success';
                    } else {
                        $status = 'Gagal';
                        echo 'badge-danger';
                    }
                    ?>"><?php echo $status ?></span></td>
            <td>
                <?php
                        if ($hasil['status'] == '1' or $hasil['status'] == '2') {
                            echo '<a href="#" class="btn btn-danger btn-sm pesanan-selesai" value=' . $hasil['id'] . '>Diterima</a>';
                        } else {
                            echo '<button class="btn btn-success btn-sm" disabled>Diterima</button>';
                        }
                        ?>
            </td>

        </tr>
        <?php }
        } else {
            echo '<tr><td colspan="8"> Anda Belum Melakukan Transaksi.. </td></tr>';
        } ?>
    </tbody>