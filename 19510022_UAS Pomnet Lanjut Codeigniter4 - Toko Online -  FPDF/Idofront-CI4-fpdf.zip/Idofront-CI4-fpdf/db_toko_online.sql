-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Bulan Mei 2021 pada 16.22
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_toko_online`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_keranjang`
--

CREATE TABLE `tbl_keranjang` (
  `id` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `jumlah_beli` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_keranjang`
--

INSERT INTO `tbl_keranjang` (`id`, `id_produk`, `id_user`, `jumlah_beli`) VALUES
(1, 22, 4, 1),
(2, 2, 4, 1),
(3, 20, 4, 1),
(4, 2, 5, 1),
(5, 19, 5, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pesanan`
--

CREATE TABLE `tbl_pesanan` (
  `id` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `alamat` text NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `total` float NOT NULL,
  `status` enum('1','2','3','4') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_pesanan`
--

INSERT INTO `tbl_pesanan` (`id`, `id_produk`, `id_user`, `alamat`, `jumlah_beli`, `total`, `status`) VALUES
(4, 1, 4, 'Jl Raya Kebonrasi No 20 RT 003 RW 002 Kel Kebonsari Kec Sukun Kota Malang 65149', 1, 23000000, '2'),
(5, 2, 4, 'Jl Raya Kebonrasi No 20 RT 003 RW 002 Kel Kebonsari Kec Sukun Kota Malang 65149', 1, 8000000, '1'),
(6, 22, 4, 'Jl Raya Kebonrasi No 20 RT 003 RW 002 Kel Kebonsari Kec Sukun Kota Malang 65149', 1, 130000000, '3'),
(7, 20, 4, 'Jl Raya Kebonrasi No 20 RT 003 RW 002 Kel Kebonsari Kec Sukun Kota Malang 65149', 1, 38000000, '4'),
(8, 1, 6, 'Jl Raya Kebonrasi No 20 RT 003 RW 002 Kel Kebonsari Kec Sukun Kota Malang 65149', 1, 23000000, '3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_produk`
--

CREATE TABLE `tbl_produk` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `harga` double NOT NULL,
  `gambar` text NOT NULL,
  `deskripsi` text NOT NULL,
  `stock` int(3) NOT NULL,
  `kategori` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_produk`
--

INSERT INTO `tbl_produk` (`id`, `nama`, `harga`, `gambar`, `deskripsi`, `stock`, `kategori`) VALUES
(1, 'DJI Phantom 4 Pro V2.0', 2300000, 'DJI-Phantom4.png', '1-inch 20MP Exmor R CMOS sensor, longer flight time and smarter features.', 28, 'Phantom'),
(2, 'DJI Phantom 3 Standart', 8000000, 'DJI-Phantom3.png', '0.3-inch 6MP Exmor R CMOS sensor, longer flight time and smarter features.', 20, 'Phantom'),
(17, 'DJI Phantom 2 Old', 13000000, 'phantom-2-c0f77edefa7396059f65c90b8c9e7647.png', '2MP Exmor R CMOS sensor, standart flight time and smarter features.', 0, 'Phantom'),
(20, 'Mavic 2 Enterprise', 38000000, 'mavic 2.png', 'Powerful Zoom Capability 12 MP 1/2.3â€ CMOS Sensor\r\nDynamic Zoom:2x Optical 3x Digital Zoom Capability\r\nPost Analysis Metadata:\r\nGPS Timestamping', 6, 'Enterprise'),
(22, 'Mavic 2 Enterprise Advanced', 46000000, 'dji-mavic-2-enterprise-advanced-drone-p7061-12438_image.jpg', 'Capture accurate details in any mission with the Mavic 2 Enterprise Advanced â€“ a highly versatile yet compact tool that packs a whole lot of performance upgrades. With high-resolution thermal and visual cameras', 6, 'Enterprise'),
(28, 'Hinokami', 9999, 'gtptqhp7k6keaxy3lsdnhng267pdmp25_hq.jpg', 'eien no homura', 108, 'Enterprise');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `nohp` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `level` enum('1','2') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `nama`, `nohp`, `email`, `level`) VALUES
(1, 'admin', '$2y$10$/BziP.4FNg47T5mFdpwdkufxBtKmovokRov1Gf0f/iuRG2MQkKldG', 'Lord Ashraf', '08983547754', 'akhikokayaba944@gmail.com', '1'),
(4, 'user', '$2y$10$K7i29Myaloaioop.sVBbuuYCVW2Bpqv7pNjP7Pfetl4GGlPd/bzza', 'Dimas Pratama ', '089123823', 'samidz@gmail.com', '2'),
(5, 'user2', '$2y$10$K7i29Myaloaioop.sVBbuuYCVW2Bpqv7pNjP7Pfetl4GGlPd/bzza', 'Qommaruddin Sifak', '0892382329', 'sifak@gmail.com', '2'),
(6, 'user5', '$2y$10$K7i29Myaloaioop.sVBbuuYCVW2Bpqv7pNjP7Pfetl4GGlPd/bzza', 'Muhammad Ashraf Rafsanjani', '0892372837', 'user5@gmail.com', '2'),
(7, 'adminpass', '$2y$10$DY4CfXn1/VWEmSkxisS9cekARBcDP1jMZRxYYBYvpgX6.Dh6EbrWa', 'getadminpass', '08012891829', 'adminpass@gmail.com', '2'),
(8, 'adminpass2', '$2y$10$pX8/b4yJXZQRzaL6BdUXd.8UpdT4xqNTQnXce27K5aQfZDRrEV5fm', 'Paimon', '029302930', 'akhikokayaba944@gmail.com', '2'),
(9, 'adminasdsad', '$2y$10$/BziP.4FNg47T5mFdpwdkufxBtKmovokRov1Gf0f/iuRG2MQkKldG', 'sdnksnd', '909201902910', 'akjdjak@gmak', '2'),
(10, 'adminaks', '$2y$10$1mUbGo1Y7fk1M7ccRC2HY.xmlzIjfKaWrEYEXnplcSw9Qfe/OQxA2', 'ksjkdnk', '098398989', 'jijdk@hij', '2'),
(11, 'askdjkjk', '$2y$10$K7i29Myaloaioop.sVBbuuYCVW2Bpqv7pNjP7Pfetl4GGlPd/bzza', 'isrofil', '819289182', 'isrofilSul@gmail.com', '2'),
(12, 'Keqing', '$2y$10$7pW5d93sCOaQo9sruBFACeMJxI35bg7m696MMn0GdSOIgTA/IFSw6', 'Keqing Trulla Cementarii', '08983547754', 'yuhengQixing@gmail.com', '2'),
(13, 'shiratorizawaac', '$2y$10$CpkFX3KORjTnZjuUSsVLa.9JX3cTRQHy5FhlA0KPl1qLYqTFjLhfC', 'Ujishima Wakatoshi', '08983547754', 'akhikokayaba944@gmail.com', '2'),
(14, 'idnextleader', '$2y$10$v/n2.jJkmS7EkpOem/NQk.hnYX1anq0kmxLgrdbGtS9lNFWxAqiFy', 'jack', '08983547754', 'akhikokayaba944@gmail.com', '2'),
(15, 'popopo', '$2y$10$E7DA0evAINZmUqQxaQNGiO16IPXoXC.Af43/dwfISM5pKvcKybs6W', 'popopop', '08983547754', 'akhikokayaba944@gmail.com', '2'),
(16, 'Sovereignofdawn', '$2y$10$G1GopDJxvR0fuSY4y9XAgOqWGz7FU6yIRk67a.nOUx6nh8CX31Nnq', 'jack', '08983547754', 'akhikokayaba944@gmail.com', '2');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_keranjang`
--
ALTER TABLE `tbl_keranjang`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_pesanan`
--
ALTER TABLE `tbl_pesanan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_produk`
--
ALTER TABLE `tbl_produk`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_keranjang`
--
ALTER TABLE `tbl_keranjang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `tbl_pesanan`
--
ALTER TABLE `tbl_pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `tbl_produk`
--
ALTER TABLE `tbl_produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
