<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelAdmin extends Model
{
   
    public function getLatestTransaksi()
    {
         return $this->db->table('tbl_pesanan')
         ->select('tbl_pesanan.id, tbl_produk.nama as nama_produk, tbl_user.nama as nama_user, tbl_pesanan.alamat, tbl_pesanan.jumlah_beli, tbl_pesanan.total, tbl_pesanan.status')
         ->join('tbl_produk','tbl_pesanan.id_produk=tbl_produk.id')
         ->join('tbl_user', 'tbl_pesanan.id_user=tbl_user.id')
         ->orderBy('tbl_pesanan.id DESC')
         ->limit(6)
         ->get()->getResultArray();  
    }

    public function getJumlah(){
        return $this->db->table('tbl_produk')
        ->select('COUNT(id) as produk, (SELECT COUNT(id) FROM tbl_pesanan) AS pesanan, (SELECT COUNT(id) FROM tbl_user WHERE level=2) AS user')  
        ->get()->getRow();
    }

    public function getPesanan(){
        return $this->db->table('tbl_pesanan')
        ->select('tbl_pesanan.id, tbl_produk.nama as nama_produk, tbl_user.nama as nama_user, tbl_pesanan.alamat, tbl_pesanan.jumlah_beli, tbl_pesanan.total, tbl_pesanan.status')
        ->join('tbl_produk','tbl_pesanan.id_produk=tbl_produk.id')
        ->join('tbl_user', 'tbl_pesanan.id_user=tbl_user.id')
        ->orderBy('tbl_pesanan.id DESC')
        ->get()->getResultArray();  
    }

    public function getPesananId($id){
        return $this->db->table('tbl_pesanan')
        ->select('tbl_pesanan.id, tbl_produk.nama as nama_produk, tbl_user.nama as nama_user, tbl_pesanan.alamat,tbl_produk.harga,tbl_produk.gambar, tbl_pesanan.jumlah_beli, tbl_pesanan.total, tbl_pesanan.status')
        ->join('tbl_produk','tbl_pesanan.id_produk=tbl_produk.id')
        ->join('tbl_user', 'tbl_pesanan.id_user=tbl_user.id')
        ->where('tbl_pesanan.id',$id)
        ->orderBy('tbl_pesanan.id DESC')
        ->get()->getRow();  
    }

    public function editPesanan($id){
        return $this->db->table('tbl_pesanan')
        ->select('tbl_pesanan.id, tbl_produk.nama as nama_produk, tbl_user.nama as nama_user, tbl_pesanan.alamat, tbl_pesanan.jumlah_beli, tbl_pesanan.total, tbl_pesanan.status')
        ->join('tbl_produk','tbl_pesanan.id_produk=tbl_produk.id')
        ->join('tbl_user', 'tbl_pesanan.id_user=tbl_user.id')
        ->where('tbl_pesanan.id',$id)
        ->orderBy('tbl_pesanan.id DESC')
        ->get()->getRow();  
    }

    public function updatePesanan($data, $id){        
        return $this->db->table('tbl_pesanan')
        ->update($data, array('id' => $id));
    }







    public function getProduk(){
        return $this->db->table('tbl_produk')
        ->get()->getResultArray();  
    }
    public function getProdukId($id){
        return $this->db->table('tbl_produk')
        ->where('id',$id)
        ->get()->getRow();  
    }

    public function tambahProduk($data){        
        return $this->db->table('tbl_produk')
        ->insert($data);
    }

    public function editProduk($id){
        return $this->db->table('tbl_produk')
        ->where('id',$id)
        ->get()->getRow();  
    }

    public function updateProduk($data, $id){        
        return $this->db->table('tbl_produk')
        ->update($data, array('id' => $id));
    }

    public function deleteProduk($id){
        return $this->db->table('tbl_produk')
        ->delete(array('id'=> $id));
    }

}