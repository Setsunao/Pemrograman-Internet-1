<?php

namespace App\Models;

use CodeIgniter\Model;

class ModelUser extends Model
{
   
    public function getProduk(){
        return $this->db->table('tbl_produk')
        ->get()->getResultArray();  
    }

    public function loginAuth($user){        
        return $this->db->table('tbl_user')
        ->where(array('username' => $user))
        ->get()->getRow();  
    }

    public function cekUser($username){        
        return $this->db->table('tbl_user')
        ->where(array('username' => $username))
        ->get()->getRow();  
    }

    public function signupAuth($data){        
        return $this->db->table('tbl_user')
        ->insert($data);
    }

    public function getProdukId($id){        
        return $this->db->table('tbl_produk')
        ->where(array('id' => $id))
        ->get()->getRow();  
    }
    
    public function updateStock($stock, $id){        
        return $this->db->table('tbl_produk')
        ->update(array('stock' => $stock) ,array('id' => $id));
    }

    public function getKeranjangId($id){  
        return $this->db->table('tbl_keranjang')
        ->select('tbl_keranjang.id, tbl_keranjang.id_produk, tbl_produk.gambar, tbl_produk.nama as nama_produk, tbl_produk.harga, tbl_keranjang.jumlah_beli, (tbl_produk.harga*tbl_keranjang.jumlah_beli) as total')
        ->join('tbl_produk','tbl_keranjang.id_produk=tbl_produk.id')
        ->join('tbl_user', 'tbl_keranjang.id_user=tbl_user.id')
        ->where(array('tbl_keranjang.id_user' => $id))
        ->orderBy('tbl_keranjang.id DESC')
        ->get()->getResultArray();  
    }
    
    public function cekKeranjang($id_produk, $id_user){        
        return $this->db->table('tbl_keranjang')
        ->where(array('id_produk' => $id_produk, 'id_user' => $id_user))
        ->get()->getRow();  
    }

    public function tambahKeranjang($data){        
        return $this->db->table('tbl_keranjang')
        ->insert($data);
    }
    
    public function updateKeranjang($data, $id_produk, $id_user){        
        return $this->db->table('tbl_keranjang')
        ->update($data ,array('id_produk' => $id_produk, 'id_user' => $id_user));
    }

    public function deleteKeranjang($id){
        return $this->db->table('tbl_keranjang')
        ->delete(array('id'=> $id));
    }

    public function badgeKeranjang($id){
        return $this->db->table('tbl_keranjang')
        ->select('SUM(jumlah_beli) AS jumlah')
        ->where(array('id_user' => $id))
        ->get()->getRow();  
    }

    public function getPesananId($id){
        return $this->db->table('tbl_pesanan')
        ->select('tbl_pesanan.id, tbl_produk.nama as nama_produk, tbl_user.nama as nama_user, tbl_pesanan.alamat,tbl_produk.harga,tbl_produk.gambar, tbl_pesanan.jumlah_beli, tbl_pesanan.total, tbl_pesanan.status')
        ->join('tbl_produk','tbl_pesanan.id_produk=tbl_produk.id')
        ->join('tbl_user', 'tbl_pesanan.id_user=tbl_user.id')
        ->where('tbl_pesanan.id_user',$id)
        ->orderBy('tbl_pesanan.id DESC')
        ->get()->getResultArray();  
    }

    public function tambahPesanan($data){    
        return $this->db->table('tbl_pesanan')
        ->insert($data);
    }
    
    public function pesananDiterima($id){        
        return $this->db->table('tbl_pesanan')
        ->update(array('status' => 2), array('id' => $id));
    }
    
    public function searchProduk($search){        
        return $this->db->table('tbl_produk')
        ->like('nama', $search)
        ->get()->getResultArray();  
    }



}