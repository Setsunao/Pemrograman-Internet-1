<?php

namespace App\Controllers;

use App\Models\ModelAdmin;
use App\ThirdParty\FPDF\FPDF;


class Admin extends BaseController
{
	public function index()
	{	
		if(session()->get('status') == 'login' && session()->get('level') == '1' && session()->get('level') == '1'){
			$model = new ModelAdmin();
			$data['result'] = $model->getLatestTransaksi();
			$data['result2'] = $model->getJumlah();
	
			return view('admin/dashboard',$data);
		}else{
            session()->setFlashdata('pesan', 'belum_login_admin');
            return redirect()->to(base_url('home/login'));
		}
	}

	public function pesanan()
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();
			$data['result'] = $model->getPesanan();
			return view('admin/pesanan', $data);
		}else{
			session()->setFlashdata('pesan', 'belum_login_admin');
			return redirect()->to(base_url('home/login'));
		}
	}

	public function editPesanan($id)
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();
			$data['hasil'] = $model->editPesanan($id);
			return view('admin/pesananEdit', $data);
		}else{
            session()->setFlashdata('pesan', 'belum_login_admin');
            return redirect()->to(base_url('home/login'));
		}
	}

	public function updatePesanan()
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();
			
			$id = $this->request->getPost('id');
			
			$data = array(
				'status' => $this->request->getPost('status')
			);
			
			$model->updatePesanan($data, $id);
			
			return redirect()->to(base_url('admin/pesanan'));
		}else{
			session()->setFlashdata('pesan', 'belum_login_admin');
			return redirect()->to(base_url('home/login'));
		}
	}


	public function produk()
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();
			$data['result'] = $model->getProduk();
			return view('admin/produk', $data);
		}else{
            session()->setFlashdata('pesan', 'belum_login_admin');
            return redirect()->to(base_url('home/login'));
		}
	}

	public function tambahProduk()
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();		
			
			$file = $this->request->getFile('gambar');
			$image = $file->getName();
			$data = array(
				'nama' => $this->request->getPost('nama_produk'),
				'harga' => $this->request->getPost('harga'),
				'stock' => $this->request->getPost('stock'),
				'deskripsi' => $this->request->getPost('deskripsi'),
				'kategori' => $this->request->getPost('kategori'),
				'gambar' => $image
			);
			
			$file->move(ROOTPATH.'public/uploads/produk');
			$model->tambahProduk($data);
			
			return redirect()->to(base_url('admin/produk'));
		}else{
			session()->setFlashdata('pesan', 'belum_login_admin');
			return redirect()->to(base_url('home/login'));
		}
		
	}

	public function editProduk($id)
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();
			$data['hasil'] = $model->editProduk($id);
			return view('admin/produkEdit', $data);
		}else{
            session()->setFlashdata('pesan', 'belum_login_admin');
            return redirect()->to(base_url('home/login'));
		}
	}

	public function updateProduk()
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();
			
			$id = $this->request->getPost('id');
		
			if(!empty($this->request->getFile('gambar')->getName())){
				$file = $this->request->getFile('gambar');
				$image = $file->getName();
				$data = array(
					'nama' => $this->request->getPost('nama_produk'),
					'harga' => $this->request->getPost('harga'),
					'stock' => $this->request->getPost('stock'),
					'deskripsi' => $this->request->getPost('deskripsi'),
					'kategori' => $this->request->getPost('kategori'),
					'gambar' => $image
				);
				$file->move(ROOTPATH.'public/uploads/produk');
			}else{
				$data = array(
					'nama' => $this->request->getPost('nama_produk'),
					'harga' => $this->request->getPost('harga'),
					'stock' => $this->request->getPost('stock'),
					'deskripsi' => $this->request->getPost('deskripsi'),
					'kategori' => $this->request->getPost('kategori')
				);
			}
			
			$model->updateProduk($data, $id);
			
			return redirect()->to(base_url('admin/produk'));
		}else{
			session()->setFlashdata('pesan', 'belum_login_admin');
			return redirect()->to(base_url('home/login'));
		}
	}

	public function deleteProduk($id)
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();
			$model->deleteProduk($id);
			return redirect()->to(base_url('admin/produk'));
		}else{
            session()->setFlashdata('pesan', 'belum_login_admin');
            return redirect()->to(base_url('home/login'));
		}
	}

	public function cetakPesanan()
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();

			$pdf = new FPDF('P','mm','A4');
			
			$pdf->AddPage();
			
			$pdf->SetFont('Arial','B',15);
			$pdf->Cell(190,25,$pdf->Image('images/logo-dark-brand.png',10,10,65,0),0,1,'R');
			$pdf->SetFont('Arial','B',18);
			$pdf->Cell(190,12,'Laporan Data Idofront - Drone Shop',0,1,'C');
			$pdf->SetFont('Arial','B',14);
			$pdf->Cell(190,7,'Data Pesanan Drone',0,1,'C');
			
			$pdf->Cell(10,7,'',0,1);

			$pdf->SetFont('Arial','B',10);

			$pdf->Cell(10, 8, 'NO',1,0, 'C');
			$pdf->Cell(85, 8, 'NAMA PRODUK', 1, 0, 'C');
			$pdf->Cell(20, 8, 'JUMLAH', 1, 0, 'C');
			$pdf->Cell(50, 8, 'TOTAL', 1, 0, 'C');
			$pdf->Cell(30, 8, 'STATUS', 1, 1, 'C');

			$pdf->SetFont('Arial','',10);
			
			$data = $model->getPesanan();
			$no = 0;
			$total = 0;
			$status = '';
			foreach ($data as $result){
				$no++;
				if($result['status'] != '4'){
					$total = $total + $result['total'];
				}

				if ($result['status'] == '1') {
					$status = 'Diproses';
				} else if ($result['status'] == '2') {
					$status = 'Diterima';
				} else if ($result['status'] == '3') {
					$status = 'Selesai';
				} else {
					$status = 'Gagal';
				}

				$pdf->Cell(10, 7, $no,1,0,'C');
				$pdf->Cell(85, 7, ' ' . $result['nama_produk'],1,0);
				$pdf->Cell(20, 7, $result['jumlah_beli'],1,0,'C'); 
				$pdf->Cell(50, 7, " Rp " . number_format($result['total'],2,',','.'),1,0); 
				$pdf->Cell(30, 7, $status,1,1); 
			}
			
			$pdf->SetFont('Arial','B',10);

			$pdf->Cell(190, 8, '', 0, 1);
			$pdf->Cell(40, 8, 'TOTAL PEMBELIAN :', 0, 0);
			$pdf->Cell(80, 8, " Rp " . number_format($total,2,',','.'), 0, 1);

			$pdf->Output();

			// return redirect()->to(base_url('admin/pesanan'));
		}else{
            session()->setFlashdata('pesan', 'belum_login_admin');
            return redirect()->to(base_url('home/login'));
		}
	}

	public function cetakProduk()
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();

			$pdf = new FPDF('P','mm','A4');
			
			$pdf->AddPage();
			
			$pdf->SetFont('Arial','B',15);
			$pdf->Cell(190,25,$pdf->Image('images/logo-dark-brand.png',10,10,65,0),0,1,'R');
			$pdf->SetFont('Arial','B',18);
			$pdf->Cell(190,12,'Laporan Data Idofront - Drone Shop',0,1,'C');
			$pdf->SetFont('Arial','B',14);
			$pdf->Cell(190,7,'Data Produk',0,1,'C');
			
			$pdf->Cell(10,7,'',0,1);

			$pdf->SetFont('Arial','B',10);

			$pdf->Cell(10, 8, 'NO',1,0, 'C');
			// $pdf->Cell(40, 8, 'GAMBAR', 1, 0, 'C');
			$pdf->Cell(80, 8, 'NAMA PRODUK', 1, 0, 'C');
			$pdf->Cell(55, 8, 'HARGA', 1, 0, 'C');
			$pdf->Cell(20, 8, 'STOCK', 1, 0, 'C');
			$pdf->Cell(30, 8, 'KATEGORI', 1, 1, 'C');

			$pdf->SetFont('Arial','',10);
			
			$data = $model->getProduk();
			$no = 0;
			foreach ($data as $result){
				$no++;
				$pdf->Cell(10, 7, $no,1,0,'C');
				// $pdf->Cell(40, 7, $pdf->Image('uploads/Produk/'.$result['gambar'],null,null,30,0),1,0);
				$pdf->Cell(80, 7, ' ' . $result['nama'],1,0);
				$pdf->Cell(55, 7, " Rp " . number_format($result['harga'],2,',','.'),1,0); 
				$pdf->Cell(20, 7, $result['stock'],1,0,'C'); 
				$pdf->Cell(30, 7, ' ' . $result['kategori'],1,1); 
			}
			
			$pdf->SetFont('Arial','B',10);

			$pdf->Output();

			// return redirect()->to(base_url('admin/pesanan'));
		}else{
            session()->setFlashdata('pesan', 'belum_login_admin');
            return redirect()->to(base_url('home/login'));
		}
	}

	public function cetakProdukId($id)
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();

			$pdf = new FPDF('P','mm','A4');
			
			$pdf->AddPage();
			$pdf->SetFont('Arial','B',15);
			$pdf->Cell(190,25,$pdf->Image('images/logo-dark-brand.png',10,10,65,0),0,1,'R');
			$pdf->SetFont('Arial','B',15);
			$pdf->Cell(190,12,'Data Produk Idofront - Drone Shop',0,1,'C');
			
			$pdf->Cell(10,5,'',0,1);
						
			$data = $model->getProdukId($id);	

			$pdf->Cell(190,5,$pdf->Image('uploads/Produk/' . $data->gambar,85,null,50,0),0,1,'C');
			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Nama Produk' ,0,0);
			$pdf->SetFont('Arial','',11);
			$pdf->Cell(40,10, ': '. $data->nama ,0,1);
			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Harga' ,0,0);
			$pdf->SetFont('Arial','',11);
			$pdf->Cell(40,10, ': '. $data->harga ,0,1);
			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Deskripsi' ,0,0);
			$pdf->SetFont('Arial','',11);
			
			$pdf->Cell(40,10, $pdf->Write(8,': '. $data->deskripsi) ,0,1);
			
			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Stock' ,0,0);
			$pdf->SetFont('Arial','',11);
			$pdf->Cell(40,10, ': '. $data->stock ,0,1);
			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Kategori' ,0,0);
			$pdf->SetFont('Arial','',11);
			$pdf->Cell(40,10, ': '. $data->kategori ,0,1);
			
			
			$pdf->SetFont('Arial','B',10);

			$pdf->Output();

			// return redirect()->to(base_url('admin/pesanan'));
		}else{
            session()->setFlashdata('pesan', 'belum_login_admin');
            return redirect()->to(base_url('home/login'));
		}
	}

	public function cetakPesananId($id)
	{
		if(session()->get('status') == 'login' && session()->get('level') == '1'){
			$model = new ModelAdmin();

			$pdf = new FPDF('P','mm','A4');
			
			$pdf->AddPage();
			$pdf->SetFont('Arial','B',15);
			$pdf->Cell(190,25,$pdf->Image('images/logo-dark-brand.png',10,10,65,0),0,1,'R');
			$pdf->SetFont('Arial','B',15);
			$pdf->Cell(190,12,'Data Pesanan Idofront - Drone Shop',0,1,'C');
			
			$pdf->Cell(10,5,'',0,1);
						
			$status = '';
			$data = $model->getPesananId($id);	

				if ($data->status == '1') {
					$status = 'Diproses';
				} else if ($data->status == '2') {
					$status = 'Diterima';
				} else if ($data->status == '3') {
					$status = 'Selesai';
				} else {
					$status = 'Gagal';
				}
				
			$pdf->Cell(190,5,$pdf->Image('uploads/Produk/' . $data->gambar,85,null,50,0),0,1,'C');

			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Nama Produk' ,0,0);
			$pdf->SetFont('Arial','',11);
			$pdf->Cell(40,10, ': '. $data->nama_produk ,0,1);
			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Pelanggan' ,0,0);
			$pdf->SetFont('Arial','',11);
			$pdf->Cell(40,10, ': '. $data->nama_user ,0,1);
			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Alamat' ,0,0);
			$pdf->SetFont('Arial','',11);
			
			$pdf->Cell(40,10, $pdf->Write(8,': '. $data->alamat) ,0,1);
			
			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Harga Satuan' ,0,0);
			$pdf->SetFont('Arial','',11);
			$pdf->Cell(40,10, ': '. "Rp " . number_format($data->harga,2,',','.') ,0,1);
			
			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Jumlah Beli' ,0,0);
			$pdf->SetFont('Arial','',11);
			$pdf->Cell(40,10, ': '. $data->jumlah_beli ,0,1);
			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Total' ,0,0);
			$pdf->SetFont('Arial','',11);
			$pdf->Cell(40,10, ': '. "Rp " . number_format($data->total,2,',','.') ,0,1);
			$pdf->SetFont('Arial','B',11);
			$pdf->Cell(40,10, 'Status' ,0,0);
			$pdf->SetFont('Arial','',11);
			$pdf->Cell(40,10, ': '. $status ,0,1);
			
			
			$pdf->SetFont('Arial','B',10);

			$pdf->Output();

			// return redirect()->to(base_url('admin/pesanan'));
		}else{
            session()->setFlashdata('pesan', 'belum_login_admin');
            return redirect()->to(base_url('home/login'));
		}
	}



}