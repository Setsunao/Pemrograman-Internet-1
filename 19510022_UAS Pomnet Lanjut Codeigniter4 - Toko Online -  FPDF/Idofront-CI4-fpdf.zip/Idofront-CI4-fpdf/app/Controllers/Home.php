<?php

namespace App\Controllers;

use App\Models\ModelUser;

class Home extends BaseController
{
	public function index()
	{
		$model = new ModelUser();
        $data['result'] = $model->getProduk();
		
		if(session()->get('status') == 'login'){
			$data['badge'] = $model->badgeKeranjang(session()->get('id'));
			return view('user/home', $data);
		}else{
			return view('user/home', $data);
		}

	}

	public function login()
	{
		return view('login');
	}

	public function loginBeli()
	{
		$session = session();
		$session->setFlashdata('pesan', 'belum_login');

		return view('login');
	}

	public function loginAuth()
	{
        $model = new ModelUser();
		$session = session();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $data = $model->loginAuth($username);

		if(password_verify($password, $data->password)){
			$sessionData = [
				'id'       => $data->id,
				'nama'     => $data->nama,
				'level'    => $data->level,
				'email'    => $data->email,
				'status'     => 'login'
			];
			$session->set($sessionData);

			if($data->level == '1'){
				return redirect()->to(base_url('admin'));
			}else{
				return redirect()->to(base_url('home'));
			}
		}else{
            $session->setFlashdata('pesan', 'gagal');
            return redirect()->to(base_url('home/login'));
        }

	}

	
	public function Logout()
	{
        $session = session();
        $session->destroy();
		session()->setFlashdata('pesan', 'logout');
		return redirect()->to(base_url('home/login'));
	}


	public function signup()
	{
		return view('signup');
	}


	public function signupAuth()
	{
        $model = new ModelUser();

		$username = $this->request->getPost('username');

        $cekUser = $model->cekUser($username);

		if(isset($cekUser)){
			session()->setFlashdata('pesan', 'duplicate');
			return redirect()->to(base_url('home/signup'));
		}else{
			$data = array(
				'username' => $this->request->getPost('username'),
				'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
				'nama' => $this->request->getPost('nama'),
				'nohp' => $this->request->getPost('nohp'),
				'email' => $this->request->getPost('email'),
				'level' => '2'
			);

			$model->signupAuth($data);

			session()->setFlashdata('pesan', 'berhasil_daftar');
			return redirect()->to(base_url('home/signup'));
		}
	}


	public function keranjang()
	{
		if(session()->get('status') == 'login'){
			$model = new ModelUser();
			$id = session()->get('id');
			$data['result'] = $model->getKeranjangId($id);
			$data['badge'] = $model->badgeKeranjang($id);

			return view('user/keranjang', $data);
		}else{
			session()->setFlashdata('pesan', 'belum_login');
			return redirect()->to(base_url('home/login'));
		}
	}


	public function tambahKeranjang($id)
	{
		if(session()->get('status') == 'login'){
			$model = new ModelUser();

			$id_produk = $id;
			$id_user = session()->get('id');

			$produk = $model->getProdukId($id_produk);

			if ($produk->stock > 0) {
				$stock = $produk->stock - 1;
				$model->updateStock($stock, $id_produk);
				$cekKeranjang = $model->cekKeranjang($id_produk, $id_user);

				if(isset($cekKeranjang)){
					$jumlah_beli = $cekKeranjang->jumlah_beli + 1;
					$data = array (
						'jumlah_beli' => $jumlah_beli 
					);
					$model->updateKeranjang($data, $id_produk, $id_user);
				}else {
					$data = array (
						'id_produk' => $id_produk, 
						'id_user' => $id_user, 
						'jumlah_beli' => 1 
					);
					$model->tambahKeranjang($data);
				}

			}

			return redirect()->to(base_url('home'));

			
		}else{
			session()->setFlashdata('pesan', 'belum_login');
			return redirect()->to(base_url('home/login'));
		}
	}

	public function deleteKeranjang($id)
	{
		if(session()->get('status') == 'login'){
			$model = new ModelUser();
			$model->deleteKeranjang($id);
			return redirect()->to(base_url('home/keranjang'));
		}else{
            session()->setFlashdata('pesan', 'belum_login');
            return redirect()->to(base_url('home/login'));
		}
	}


	public function checkout()
	{
		if(session()->get('status') == 'login'){
			$model = new ModelUser();

			$id_user = session()->get('id');
			$alamat = $this->request->getPost('alamat');
		
			$data = $model->getKeranjangId($id_user);
			foreach($data as $result){
				$dataPesanan = array(
					'id' => $result['id'],
					'id_produk' => $result['id_produk'],
					'id_user' => $id_user,
					'alamat' => $alamat,
					'jumlah_beli' => $result['jumlah_beli'],
					'total' => $result['total'],
					'status' => '1'
				);
				$model->tambahPesanan($dataPesanan);
				$model->deleteKeranjang($result['id']);
			}
			return redirect()->to(base_url('home')); //rdrc to pesanan

			
		}else{
			session()->setFlashdata('pesan', 'belum_login');
			return redirect()->to(base_url('home/login'));
		}
	}

	public function pesanan()
	{
		if(session()->get('status') == 'login'){
			$model = new ModelUser();
			$id = session()->get('id');
			$data['result'] = $model->getPesananId($id);
			$data['badge'] = $model->badgeKeranjang($id);

			return view('user/pesanan', $data);
		}else{
			session()->setFlashdata('pesan', 'belum_login');
			return redirect()->to(base_url('home/login'));
		}
	}

	public function pesananDiterima($id)
	{
		if(session()->get('status') == 'login'){
			$model = new ModelUser();
			
			$model->pesananDiterima($id);

			return redirect()->to(base_url('home/pesanan'));
		}else{
			session()->setFlashdata('pesan', 'belum_login');
			return redirect()->to(base_url('home/login'));
		}
	}


	public function searchProduk()
	{
		$model = new ModelUser();
		$search = $this->request->getPost('search');
        $data['result'] = $model->searchProduk($search);

		if(session()->get('status') == 'login'){
			$data['badge'] = $model->badgeKeranjang(session()->get('id'));
		}
		echo view('user/home', $data);
		

	}


}

