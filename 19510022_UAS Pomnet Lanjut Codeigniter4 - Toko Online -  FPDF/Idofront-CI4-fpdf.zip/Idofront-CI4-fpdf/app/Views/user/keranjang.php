<?= $this->extend('user/layout/user_layout') ?>

<?= $this->section('badge') ?>

<?php
        echo '<div class="dropdown d-none d-lg-inline-block pt-3">
                <a href="'.base_url('home/keranjang').'" class="btn header-item noti-icon waves-effect">
                    <i class="mdi mdi-cart"></i>
                    <span class="badge badge-danger badge-pill" style=" top: 7px;">'.$badge->jumlah.'</span>
                </a>
            </div>
            <div class="dropdown d-none d-lg-inline-block pt-3">
                <a href="'.base_url('home/pesanan').'" class="btn header-item noti-icon waves-effect">
                    <i class="mdi mdi-basket"></i>
                </a>
            </div>';
    ?>

<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Keranjang Belanja</h4>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item active"></li>
                        </ol>
                    </div>
                </div>
            </div>

            <div class="modal fade modal-checkout" tabindex="-1" role="dialog" aria-labelledby="modal-checkout"
                aria-hidden="true" >
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <form id="pesanan-edit-data" class="custom-validation" method="POST"
                            enctype="multipart/form-data" action="<?php echo site_url('home/checkout'); ?>" >
                            <div class="modal-header">
                                <h5 class="modal-title mt-0" id="modal-checkout">Checkout</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                            </div>
                            <div class="modal-body" id="form-checkout">
                                <div class="form-group">
                                    <label>Alamat Lengkap</label>
                                    <textarea class="form-control" name="alamat" rows="5" required></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="reset" class="btn btn-primary waves-effect" data-dismiss="modal"
                                    aria-hidden="true">
                                    Cancel
                                </button>
                                <button type="submit" class="btn btn-success waves-effect waves-light mr-1">
                                    Checkout
                                </button>
                            </div>
                        </form>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->


            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body" id="keranjang-tampil">
                            <table class="table table-hover table-centered table-nowrap mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col" width="100px">Gambar</th>
                                        <th scope="col">Nama Produk</th>
                                        <th scope="col">Harga Satuan</th>
                                        <th scope="col">Jumlah Beli</th>
                                        <th scope="col">Harga</th>
                                        <th scope="col">Update</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no = 1;
                                        $total = 0;

                                        if (count($result) > 0) {
                                            foreach($result as $hasil):
                                                $total = $total + $hasil['total'];
                                        ?>
                                    <tr>
                                        <th scope="row"><?php echo $no++; ?></td>
                                        <td><img src="<?php echo '../uploads/Produk/' . $hasil['gambar']; ?>"
                                                class='img-fluid' /></td>
                                        <td><?php echo $hasil['nama_produk']; ?></td>
                                        <td>Rp. <?php echo number_format($hasil['harga'], 2, ',', '.'); ?></td>
                                        <td><?php echo $hasil['jumlah_beli']; ?></td>
                                        <td>Rp. <?php echo number_format($hasil['total'], 2, ',', '.'); ?></td>
                                        <td><a href="<?php echo site_url('home/deleteKeranjang/'.$hasil['id']); ?>"
                                                class="btn btn-danger btn-sm keranjang-hapus"
                                                value="<?php echo $hasil['id']; ?>">Hapus</a>
                                        </td>
                                    </tr>
                                    <?php endforeach;
                                    } else {
                                        echo '<tr><td colspan="7"> Belum ada produk dalam keranjang belanja..</td></tr>';
                                    } ?>
                                    <tr>
                                        <td colspan="7"></td>
                                    </tr>
                                    <tr>
                                        <td class='font-weight-bold text-right h4' colspan='5'></td>
                                        <td class='h4 text-right' colspan="2"><span class="font-weight-normal">Total
                                                Harga &nbsp;&nbsp;</span> Rp.
                                            <?php echo number_format($total, 2, ',', '.'); ?></td>
                                    </tr>
                                    <tr>
                                        <td class='font-weight-bold' colspan='5'></td>
                                        <td class='text-right h4' colspan="2">
                                            <?php
                                            if (count($result) > 0) {
                                                echo '<button type="button" class="btn btn-success waves-effect waves-light pesanan-edit " data-toggle="modal" data-target=".modal-checkout">Checkout</button>';
                                            } else {
                                                echo '<button type="button" class="btn btn-success waves-effect waves-light" disabled>Checkout</button>';
                                            } ?>


                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- end card -->
                    </div>
                </div>
            </div>
        </div> <!-- container-fluid -->
    </div>
</div>

<?= $this->endSection() ?>


<?= $this->section('script') ?>

<script>
$('.carousel').carousel();
</script>

<?= $this->endSection() ?>