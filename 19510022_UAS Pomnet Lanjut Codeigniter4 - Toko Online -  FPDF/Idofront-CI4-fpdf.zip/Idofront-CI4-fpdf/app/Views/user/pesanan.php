<?= $this->extend('user/layout/user_layout') ?>

<?= $this->section('badge') ?>

<?php
        echo '<div class="dropdown d-none d-lg-inline-block pt-3">
                <a href="'.base_url('home/keranjang').'" class="btn header-item noti-icon waves-effect">
                    <i class="mdi mdi-cart"></i>
                    <span class="badge badge-danger badge-pill" style=" top: 7px;">'.$badge->jumlah.'</span>
                </a>
            </div>
            <div class="dropdown d-none d-lg-inline-block pt-3">
                <a href="button" class="btn header-item noti-icon waves-effect">
                    <i class="mdi mdi-basket"></i>
                </a>
            </div>';
    ?>

<?= $this->endSection() ?>

<?= $this->section('content') ?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Daftar Transaksi</h4>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item active"></li>
                        </ol>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body" id="keranjang-tampil">
                            <table class="table table-hover table-centered table-nowrap mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama Produk</th>
                                        <th scope="col" style="width: 250px !important;">Alamat</th>
                                        <th scope="col">Jumlah Beli</th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no = 1;
                                        $total = 0;

                                        if (count($result) > 0) {
                                            foreach($result as $hasil):
                                                $total = $total + $hasil['total'];
                                        ?>
                                    <tr>
                                        <th scope="row"><?php echo $no++; ?></td>
                                        <td><?php echo $hasil['nama_produk']; ?></td>
                                        <td><?php echo $hasil['alamat']; ?></td>
                                        <td><?php echo $hasil['jumlah_beli']; ?></td>
                                        <td><?php echo number_format($hasil['total'], 2, ',', '.'); ?></td>
                                        <td><span class="badge 
                                                <?php
                                                    if ($hasil['status'] == '1') {
                                                        $status = 'Diproses';
                                                        echo 'badge-primary';
                                                    } else if ($hasil['status'] == '2') {
                                                        $status = 'Diterima';
                                                        echo 'badge-warning';
                                                    } else if ($hasil['status'] == '3') {
                                                        $status = 'Selesai';
                                                        echo 'badge-success';
                                                    } else {
                                                        $status = 'Gagal';
                                                        echo 'badge-danger';
                                                    }
                                                ?>">
                                            <?php echo $status ?></span></td>
                                        <td>
                                            <?php
                                                if ($hasil['status'] == '1') {
                                                    echo '<a href="'.site_url('home/pesananDiterima/'.$hasil['id']).'" class="btn btn-danger btn-sm pesanan-selesai" value=' . $hasil['id'] . '>Diterima</a>';
                                                } else {
                                                    echo '<button class="btn btn-success btn-sm" disabled>Diterima</button>';
                                                }
                                            ?>
                                        </td>
                                    </tr>
                                    <?php endforeach;
                                    } else {
                                        echo '<tr><td colspan="7"> Belum ada produk dalam keranjang belanja..</td></tr>';
                                    } ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- end card -->
                    </div>
                </div>
            </div>
        </div> <!-- container-fluid -->
    </div>
</div>

<?= $this->endSection() ?>


<?= $this->section('script') ?>

<script>
$('.carousel').carousel();
</script>

<?= $this->endSection() ?>