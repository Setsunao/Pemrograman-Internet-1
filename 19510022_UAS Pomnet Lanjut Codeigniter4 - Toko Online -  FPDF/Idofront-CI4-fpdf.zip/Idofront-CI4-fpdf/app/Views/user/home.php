<?= $this->extend('user/layout/user_layout') ?>

<?= $this->section('badge') ?>

<?php
        if (@session()->get('status') == 'login') {
          echo '<div class="dropdown d-none d-lg-inline-block pt-3">
                    <a href="'.base_url('home/keranjang').'" class="btn header-item noti-icon waves-effect">
                        <i class="mdi mdi-cart"></i>
                        <span class="badge badge-danger badge-pill" style=" top: 7px;">'.$badge->jumlah.'</span>
                    </a>
                </div>
                <div class="dropdown d-none d-lg-inline-block pt-3">
                    <a href="'.base_url('home/pesanan').'" class="btn header-item noti-icon waves-effect">
                        <i class="mdi mdi-basket"></i>
                    </a>
                </div>';
        } 
    ?>

<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="main-content">
    <div class="page-content mx-0 mt-0 px-0">
        <div id="carouselExampleCaption" class="carousel slide shadow-sm" data-ride="carousel">
            <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                    <img src="/images/img-6.jpg" alt="..." class="d-block img-fluid" style="min-height: 550px;">
                    <div class="carousel-caption d-none d-md-block text-white" style="background-color: #00000040;">
                        <h5>Mavic 2 Enterprise Advanced</h5>
                        <p>Dual Iamging Reimagined.</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="/images/img-1.jpg" alt="..." class="d-block img-fluid" style="min-height: 550px;">
                    <div class="carousel-caption d-none d-md-block text-white" style="background-color: #00000040;">
                        <h5>DJI Mini 2</h5>
                        <p>Make Your Moments Fly.</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="/images/img-2.jpg" alt="..." class="d-block img-fluid" style="min-height: 550px;">
                    <div class="carousel-caption d-none d-md-block text-white" style="background-color: #00000040;">
                        <h5>Agras T20</h5>
                        <p>Intelligent and Powerful.</p>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="/#carouselExampleCaption" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="/#carouselExampleCaption" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
        <div class="container-fluid">

            <div class="row align-items-center">
                <div class="col-sm-4">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Newest Product</h4>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item active">The Future Of Possible</li>
                        </ol>
                    </div>
                </div>
                <div class="col-sm-4">
                </div>
                <div class="col-sm-4">
                    <form class="app-search d-none d-lg-block" method="POST" enctype="multipart/form-data"
                        action="<?php echo site_url('home/searchProduk') ?>">
                        <div class="position-relative">
                            <input type="text" class="form-control search" name="search" placeholder="Cari produk...">
                            <span class="fa fa-search"></span>
                        </div>
                        <input type="submit" style="position: absolute; left: -9999px; width: 1px; height: 1px;"
                            tabindex="-1">
                    </form>
                </div>
                <div class="row w-100" id="produk-tampil">
                    
                    <?php 
                    
                        if(count($result)>0){

                            foreach($result as $hasil): ?>

                            <div class="col-md-3 col-lg-3 ">
                                <div class="card shadow-sm rounded border">
                                    <img class="card-img-top img-fluid"
                                        src="<?php echo base_url('uploads/produk/'. $hasil['gambar']) ?>" alt="product-img">
                                    <div class="card-body">
                                        <h4 class="card-title  mt-0"><?php echo $hasil['nama']; ?></h4>
                                        <p class="card-text">Rp. <?php echo number_format($hasil['harga'], 2, ',', '.'); ?></p>
                                        <?php
                                            if (@session()->get('status') == 'login') {
                                                if ($hasil['stock'] < 1) {
                                                    echo '<button class="btn btn-warning waves-effect waves-light " disabled>Stock Habis</button>';
                                                } else {
                                                    echo '<a href="'.site_url('home/tambahKeranjang/'.$hasil['id']).'" class="btn btn-primary waves-effect waves-light produk-tambah-keranjang">Tambah Ke Keranjang</a>';
                                                }
                                            } else {
                                                if ($hasil['stock'] < 1) {
                                                    echo '<button class="btn btn-warning waves-effect waves-light " disabled>Stock Habis</button>';
                                                } else {
                                                    echo '<a href="'. base_url('home/login') .'" class="btn btn-danger waves-effect waves-light" >Login untuk beli</a>';
                                                }
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>

                            <?php endforeach;
                        
                        }else{
                            echo '<h3 class="my-4 mx-4">Produk tidak ditemukan...</h3>';
                        }
                    ?>

                </div>


            </div> <!-- container-fluid -->
        </div>
    </div>
    <!-- End Page-content -->
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    © 2021 Idofront <span class="d-none d-sm-inline-block"> - @Muhammad Ashraf
                        Rafsanjani - 19510022 <i class="mdi mdi-heart text-danger"></i></span>
                </div>
            </div>
        </div>
    </footer>
</div>


<?= $this->endSection() ?>


<?= $this->section('script') ?>

<script>
$('.carousel').carousel();
</script>

<?= $this->endSection() ?>