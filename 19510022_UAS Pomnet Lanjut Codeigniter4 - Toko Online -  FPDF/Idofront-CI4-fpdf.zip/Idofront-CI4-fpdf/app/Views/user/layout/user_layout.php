<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Idofront | Drone Shop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="/images/favicon.ico">
    <!-- Bootstrap Css -->
    <!-- -->
    <link href="/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="" id="app-style" rel="stylesheet" type="text/css" />

    <style>
    #produk-tampil .card img {
        vertical-align: middle;
        border-style: none;
        width: 100%;
        max-width: 350px;
        height: 250px;
        object-fit: cover;
        padding: 30px;
    }

    .search {
        background-color: #848187 !important;
        border: 1px solid #848187 !important;
    }


    .navbar-header {
        height: 80px;
    }

    #page-topbar {
        background-color: #454965 !important;
    }
    </style>

</head>

<body data-topbar="dark" data-layout="horizontal">
    <!-- Begin page -->
    <div id="layout-wrapper" style="background-color: #eaeaea;">

        <header id="page-topbar">
            <div class="navbar-header">
                <div class="d-flex">
                    <!-- LOGO -->
                    <div class="navbar-brand-box">
                        <a href="<?php echo base_url('') ?>" class="logo logo-light">
                            <span class="logo-sm">
                                <img src="/images/logo-sm.png" alt="" height="25">
                            </span>
                            <span class="logo-lg">
                                <img src="/images/logo-light-brand.png" alt="" height="45">
                            </span>
                        </a>

                    </div>

                    <button type="button"
                        class="btn btn-sm mr-2 font-size-24 d-lg-none header-item waves-effect waves-light"
                        data-toggle="collapse" data-target="#topnav-menu-content">
                        <i class="mdi mdi-menu"></i>
                    </button>

                </div>

                <div class="d-flex">

                    <!-- <form class="app-search d-none d-lg-block pt-4 pr-3">
                        <div class="position-relative">
                            <input type="text" class="form-control" id="searchProduk" placeholder="Search...">
                            <span class="fa fa-search"></span>
                        </div>
                    </form> -->

                    <?= $this->renderSection('badge');?>

                    <div class="dropdown d-inline-block pt-3">
                        <a type="button" class="btn header-item waves-effect" id="page-header-user-dropdown"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="rounded-circle header-profile-user" src="/images/profile.jpg"
                                alt="Header Avatar">
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <!-- item-->
                            <?php
                    if (@session()->get('status') != 'login') {
                        echo '<a class="dropdown-item text-danger" href="'.base_url('home/login').'"><i class="bx bx-power-off font-size-17 align-middle mr-1 text-primary"></i> Login</a>';
                    } else {
                        echo '<a class="dropdown-item text-danger" href="'.base_url('home/logout').'"><i class="bx bx-power-off font-size-17 align-middle mr-1 text-danger"></i> Logout</a>';
                    }
                    ?>
                        </div>
                    </div>
                </div>

            </div>
        </header>



        <?= $this->renderSection('content') ?>

    </div>

    <!-- JAVASCRIPT -->


    <script src="/libs/jquery/jquery2.min.js"></script>
    <script src="/libs/jquery/jquery2.min.js"></script>
    <script src="/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/libs/metismenu/metisMenu.min.js"></script>
    <script src="/libs/simplebar/simplebar.min.js"></script>
    <script src="/libs/node-waves/waves.min.js"></script>

    <!-- Required datatable js -->
    <script src="/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <!-- Buttons examples -->
    <!-- <script src="/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script> -->
    <!-- <script src="/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script> -->
    <!-- <script src="/libs/jszip/jszip.min.js"></script> -->
    <!-- <script src="/libs/pdfmake/build/pdfmake.min.js"></script> -->
    <!-- <script src="/libs/pdfmake/build/vfs_fonts.js"></script> -->
    <!-- <script src="/libs/datatables.net-buttons/js/buttons.php5.min.js"></script> -->
    <!-- <script src="/libs/datatables.net-buttons/js/buttons.print.min.js"></script> -->
    <!-- <script src="/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script> -->
    <!-- Responsive examples -->
    <!-- <script src="/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script> -->
    <!-- <script src="/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script> -->
    <!-- <script src="/libs/admin-resources/bootstrap-filestyle/bootstrap-filestyle.min.js"></script> -->

    <!-- Datatable init js -->
    <!-- <script src="/js/pages/datatables.init.js"></script> -->
    <!-- <script src="/libs/jquery/jquery.min.js"></script>   -->


    <script src="/js/app.js"></script>

    <?= $this->renderSection('script') ?>


</body>

</html>