<?= $this->extend('admin/layout/admin_layout') ?>

<?= $this->section('content') ?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Pesanan</h4>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item active">Selamat Datang Admin -
                                <?php echo session()->get('nama'); ?>
                            </li>
                        </ol>
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="float-right d-none d-md-block">
                        <a href="<?php echo site_url('admin/cetakPesanan') ?>"
                            class="btn btn-primary waves-effect waves-light"><i class="typcn typcn-printer"></i> Cetak
                            Data</a>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body" id="pesanan-tampil">
                            <h4 class="card-title mb-4">List Pesanan</h4>

                            <table id="datatable" class="table table-bordered dt-responsive nowrap"
                                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Produk</th>
                                        <th class="longText">Pelanggan</th>
                                        <th class="longText">Alamat</th>
                                        <th class="longText">Jumlah Beli</th>
                                        <th>Total</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>


                                <tbody>

                                    <?php
                                        $no = 1;
                                        foreach ($result as $hasil): ?>

                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo $hasil['nama_produk']; ?></td>
                                        <td class="longText"><?php echo $hasil['nama_user']; ?></td>
                                        <td class="longText"><?php echo $hasil['alamat']; ?></td>
                                        <td><?php echo $hasil['jumlah_beli']; ?></td>
                                        <td><?php echo "Rp " . number_format($hasil['total'],2,',','.'); ?></td>
                                        <td><span class="badge badge-<?php
                                                if ($hasil['status'] == '1') {
                                                    $status = 'Diproses';
                                                    echo 'primary';
                                                } else if ($hasil['status'] == '2') {
                                                    $status = 'Diterima';
                                                    echo 'warning';
                                                } else if ($hasil['status'] == '3') {
                                                    $status = 'Selesai';
                                                    echo 'success';
                                                } else {
                                                    $status = 'Gagal';
                                                    echo 'danger';
                                                }
                                                ?>"><?php echo $status ?></span></td>
                                        <td>
                                            <div>
                                                <a href="<?php echo site_url('admin/editPesanan/'.$hasil['id']); ?>"
                                                    class="btn btn-warning btn-sm pesanan-edit">Edit</a>
                                                <a href="<?php echo site_url('admin/cetakPesananId/'.$hasil['id']); ?>"
                                                    class="btn btn-primary btn-sm pesanan-edit">Cetak</a>
                                            </div>
                                        </td>
                                    </tr>

                                    <?php endforeach; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- end card -->
                </div>

            </div>
            <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

    <?= $this->endSection() ?>


    <?= $this->section('script') ?>

    <script>
    $(document).ready(function() {

        $('#datatable').dataTable();

    });
    </script>

    <?= $this->endSection() ?>