<?= $this->extend('admin/layout/admin_layout') ?>

<?= $this->section('content') ?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Edit Pesanan</h4>
                    </div>
                </div>

            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <form class="custom-validation" method="POST" enctype="multipart/form-data"
                                action="<?php echo site_url('admin/updatePesanan') ?>">

                                <div class="form-group">
                                    <label>Nama Produk</label>
                                    <input type="hidden" name="id" class="form-control"
                                        value="<?php echo $hasil->id; ?>" required />
                                    <input type="text" name="nama_produk" class="form-control text-muted"
                                        value="<?php echo $hasil->nama_produk; ?>" required disabled />
                                </div>

                                <div class="form-group">
                                    <label>Nama Pelanggan</label>
                                    <input type="text" name="nama_user" class="form-control text-muted"
                                        value="<?php echo $hasil->nama_user; ?>" required disabled />
                                </div>

                                <div class="form-group">
                                    <label>Alamat</label>
                                    <textarea class="form-control text-muted" name="alamat" rows="5" required
                                        disabled><?php echo $hasil->alamat; ?></textarea>
                                </div>

                                <div class="form-row">
                                    <div class="col-6 mb-3">
                                        <label>Jumlah Beli</label>
                                        <input type="number" name="jumlah_beli" class="form-control text-muted"
                                            value="<?php echo $hasil->jumlah_beli; ?>" required disabled />
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label>Total</label>
                                        <input type="number" name="total" class="form-control text-muted"
                                            value="<?php echo $hasil->total; ?>" required disabled />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <select class="form-control" name="status" required>
                                        <option value='1' <?php if ($hasil->status == "1") echo 'selected'; ?>>
                                            Diproses</option>
                                        <option value='2' <?php if ($hasil->status == "2") echo 'selected'; ?>>
                                            Diterima</option>
                                        <option value='3' <?php if ($hasil->status == "3") echo 'selected'; ?>>Selesai
                                        </option>
                                        <option value='4' <?php if ($hasil->status == "4") echo 'selected'; ?>>Gagal
                                        </option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success waves-effect waves-light mr-1">
                                        Submit
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>



        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

    <?= $this->endSection() ?>

