<?= $this->extend('admin/layout/admin_layout') ?>

<?= $this->section('content') ?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Edit Data</h4>
                    </div>
                </div>

            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                            <form class="custom-validation" method="POST" enctype="multipart/form-data"
                                action="<?php echo site_url('admin/updateProduk') ?>">

                                <div class="form-group">
                                    <label>Nama Produk</label>
                                    <input type="hidden" name="id" class="form-control"
                                        value="<?php echo $hasil->id; ?>" required />
                                    <input type="text" name="nama_produk" class="form-control"
                                        value="<?php echo $hasil->nama; ?>" required />
                                </div>

                                <div class="form-row">
                                    <div class="col-6 mb-3">
                                        <label>Harga</label>
                                        <input type="number" name="harga" class="form-control"
                                            value="<?php echo $hasil->harga; ?>" required />
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label>Stock</label>
                                        <input type="number" name="stock" class="form-control"
                                            value="<?php echo $hasil->stock; ?>" required />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Deskripsi</label>
                                    <textarea class="form-control" name="deskripsi" rows="5"
                                        required><?php echo $hasil->deskripsi; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label>Kategori</label>
                                    <select class="form-control" name="kategori" required>
                                        <option>-- Pilih --</option>
                                        <option value='Phantom'
                                            <?php if($hasil->kategori=="Phantom") echo 'selected'; ?>>Phantom
                                        </option>
                                        <option value='Inspire'
                                            <?php if($hasil->kategori=="Inspire") echo 'selected'; ?>>Inspire
                                        </option>
                                        <option value='Enterprise'
                                            <?php if($hasil->kategori=="Enterprise") echo 'selected'; ?>>
                                            Enterprise
                                        </option>
                                        <option value='Ryze-Tech'
                                            <?php if($hasil->kategori=="Ryze-Tech") echo 'selected'; ?>>Ryze
                                            Tech
                                        </option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Gambar Produk</label>
                                    <input class="filestyle" name="gambar" type="file" accept="image/x-png,image/jpeg">
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success waves-effect waves-light mr-1">
                                        Submit
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>



        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

    <?= $this->endSection() ?>


    <?= $this->section('script') ?>



    <?= $this->endSection() ?>