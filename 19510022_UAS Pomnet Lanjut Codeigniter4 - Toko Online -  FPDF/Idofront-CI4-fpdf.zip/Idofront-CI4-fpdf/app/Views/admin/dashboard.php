<?= $this->extend('admin/layout/admin_layout') ?>

<?= $this->section('content') ?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->

            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Dashboard</h4>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item active">Selamat Datang Admin -
                            <?php echo session()->get('nama'); ?>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
            <!-- end page title -->
            <div class="row">
                <div class="col-xl-4 col-md-6">
                    <div class="card mini-stat bg-primary text-white">
                        <div class="card-body">
                            <div class="mb-4">
                                <div class="float-left mini-stat-img mr-4">
                                    <img src="/images/services-icon/03.png" alt="">
                                </div>
                                <h5 class="font-size-16 text-uppercase mt-0 text-white-50">Jumlah Produk</h5>
                                <h4 class="font-weight-medium font-size-24">
                                    <?php echo $result2->produk ?>
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card mini-stat bg-primary text-white">
                        <div class="card-body">
                            <div class="mb-4">
                                <div class="float-left mini-stat-img mr-4">
                                    <img src="/images/services-icon/01.png" alt="">
                                </div>
                                <h5 class="font-size-16 text-uppercase mt-0 text-white-50">Jumlah Pesanan</h5>
                                <h4 class="font-weight-medium font-size-24">
                                    <?php echo $result2->pesanan ?>
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card mini-stat bg-primary text-white">
                        <div class="card-body">
                            <div class="mb-4">
                                <div class="float-left mini-stat-img mr-4">
                                    <img src="/images/services-icon/02.png" alt="">
                                </div>
                                <h5 class="font-size-16 text-uppercase mt-0 text-white-50">Total Pelanggan</h5>
                                <h4 class="font-weight-medium font-size-24">
                                    <?php echo $result2->user ?>
                                </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body" id="pesanan-tampil">
                            <h4 class="card-title mb-4">Transaksi Terbaru</h4>
                            <table class="table table-hover table-centered mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama Produk</th>
                                        <th scope="col">Pelanggan</th>
                                        <th scope="col" width="250px">Alamat</th>
                                        <th scope="col">Jumlah Beli</th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php 
                                        $no = 1; 
                                        foreach($result as $hasil): ?>

                                    <tr>
                                        <th scope="row"><?php echo $no++; ?></td>
                                        <td><?php echo $hasil['nama_produk']; ?></td>
                                        <td><?php echo $hasil['nama_user']; ?></td>
                                        <td><?php echo $hasil['alamat']; ?></td>
                                        <td><?php echo $hasil['jumlah_beli']; ?></td>
                                        <td><?php echo  "Rp " . number_format($hasil['total'],2,',','.'); ?></td>
                                        <td><span class="badge badge-<?php
                                            if ($hasil['status'] == '1') {
                                                $status = 'Diproses';
                                                echo 'primary';
                                            } else if ($hasil['status'] == '2') {
                                                $status = 'Diterima';
                                                echo 'warning';
                                            } else if ($hasil['status'] == '3') {
                                                $status = 'Selesai';
                                                echo 'success';
                                            } else {
                                                $status = 'Gagal';
                                                echo 'danger';
                                            }
                                            ?>"><?php echo $status ?></span>
                                        </td>
                                    </tr>

                                    <?php endforeach; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- end card -->
                </div>

            </div>
            <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    © 2021 Idofront <span class="d-none d-sm-inline-block"> - @Muhammad Ashraf
                        Rafsanjani - 19510022 <i class="mdi mdi-heart text-danger"></i></span>
                </div>
            </div>
        </div>
    </footer>

</div>
<!-- end main content-->

<?= $this->endSection() ?>
