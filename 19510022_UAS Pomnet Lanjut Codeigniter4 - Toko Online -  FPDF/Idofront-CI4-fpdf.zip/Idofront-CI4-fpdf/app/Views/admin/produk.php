<?= $this->extend('admin/layout/admin_layout') ?>

<?= $this->section('content') ?>

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">
            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Produk</h4>
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item active">Selamat Datang Admin -
                                <?php echo session()->get('nama'); ?>
                            </li>
                        </ol>
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="float-right d-none d-md-block">
                        <button type="button" class="btn btn-success waves-effect waves-light" data-toggle="modal"
                            data-target=".modal-tambah-produk"><i class="typcn typcn-plus"></i> Tambah Data</button>
                    </div>
                    <div class="float-right d-none d-md-block mr-4">
                        <a href="<?php echo site_url('admin/cetakProduk') ?>" class="btn btn-primary waves-effect waves-light"><i class="typcn typcn-printer"></i> Cetak Data Produk</a>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body" id="produk-tampil">
                            <h4 class="card-title mb-4">List Produk</h4>

                            <table id="datatable2" class="table table-bordered dt-responsive nowrap"
                                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th class="longText" width="100px">Gambar</th>
                                        <th>Nama Produk</th>
                                        <th>Harga</th>
                                        <th class="longText" width="200px">Deskripsi</th>
                                        <th>Stock</th>
                                        <th>Kategori</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>


                                <tbody>

                                    <?php
                                        $no = 1;
                                        foreach ($result as $hasil): ?>


                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td class="longText"><img src="<?php echo '../uploads/Produk/' . $hasil['gambar']; ?>"
                                                class='img-fluid' /></td>
                                        <td><?php echo $hasil['nama']; ?></td>
                                        <td><?php echo "Rp " . number_format($hasil['harga'],2,',','.'); ?></td>
                                        <td class="longText"><?php echo $hasil['deskripsi']; ?></td>
                                        <td><?php echo $hasil['stock']; ?></td>
                                        <td><span class="badge badge-<?php
                                                if ($hasil['kategori'] == 'Phantom') {
                                                    echo 'danger';
                                                } else if ($hasil['kategori'] == 'Inspire') {
                                                    echo 'success';
                                                } else if ($hasil['kategori'] == 'Enterprise') {
                                                    echo 'warning';
                                                } else {
                                                    echo 'primary';
                                                }
                                                ?>"><?php echo $hasil['kategori']; ?></span></td>
                                        <td>
                                            <div>
                                                <a href="<?php echo site_url('admin/editProduk/'.$hasil['id']); ?>"
                                                    class="btn btn-warning btn-sm produk-edit">
                                                    Edit</a>
                                                <a href="<?php echo site_url('admin/cetakProdukId/'.$hasil['id']); ?>"
                                                    class="btn btn-primary btn-sm">
                                                    Cetak</a>
                                                <a href="#"
                                                    href-data="<?php echo site_url('admin/deleteProduk/'.$hasil['id']); ?>"
                                                    class="btn btn-danger btn-sm produk-hapus" data-toggle="modal"
                                                    data-target="#modal-delete">Hapus</a>
                                            </div>
                                        </td>
                                    </tr>

                                    <?php endforeach; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- end card -->
                </div>

            </div>
            <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

    <div class="modal fade modal-tambah-produk" tabindex="-1" role="dialog" aria-labelledby="modal-tambah-produk"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form id="produk-tambah-data" class="custom-validation" method="POST" enctype="multipart/form-data"
                    action="<?php echo site_url('admin/tambahProduk') ?>">
                    <div class="modal-header">
                        <h5 class="modal-title mt-0" id="modal-tambah-produk">Tambah Produk</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group">
                            <label>Nama Produk</label>
                            <input type="text" name="nama_produk" class="form-control" required />
                        </div>

                        <div class="form-row">
                            <div class="col-6 mb-3">
                                <label>Harga</label>
                                <input type="number" name="harga" class="form-control" required />
                            </div>
                            <div class="col-6 mb-3">
                                <label>Stock</label>
                                <input type="number" name="stock" class="form-control" required />
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Deskripsi</label>
                            <textarea class="form-control" name="deskripsi" rows="5" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Kategori</label>
                            <select class="form-control" name="kategori" required>
                                <option>-- Pilih --</option>
                                <option value='Phantom'>Phantom</option>
                                <option value='Inspire'>Inspire</option>
                                <option value='Enterprise'>Enterprise</option>
                                <option value='Ryze-Tech'>Ryze Tech</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Gambar Produk</label>
                            <input class="filestyle" name="gambar" type="file" accept="image/x-png,image/jpeg" required>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-primary waves-effect" data-dismiss="modal"
                            aria-hidden="true">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-success waves-effect waves-light mr-1">
                            Submit
                        </button>
                    </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <div class="modal fade modal-delete" id="modal-delete" tabindex="-1" role="dialog" aria-labelledby="modal-delete"
        aria-hidden="true">
        <div class="modal-dialog ">
            <div class="modal-content">
                <form id="produk-delete" class="custom-validation" method="POST" enctype="multipart/form-data">
                    <div class="modal-body" id="form-edit-pesanan">
                        <h3>Yakin Hapus data?</h3>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-primary waves-effect" data-dismiss="modal"
                            aria-hidden="true">
                            Cancel
                        </button>
                        <a class="btn btn-danger waves-effect waves-light mr-1 btn-delete" id="btn-dlt">
                            Hapus
                        </a>
                    </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

    <?= $this->endSection() ?>


    <?= $this->section('script') ?>

    <script>
    $(document).ready(function() {

        $('#datatable2').dataTable();

    });

    $(document).on('click', '.produk-hapus', function() {
        var href = $(this).attr("href-data");
        $('#btn-dlt').attr('href', href);
    });
    </script>

    <?= $this->endSection() ?>