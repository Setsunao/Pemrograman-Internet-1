<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Signup | Idofront</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="/images/favicon.ico">

    <!-- Bootstrap Css -->
    <link href="/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="/css/app.min.css" rel="stylesheet" type="text/css" />
    <link href="" id="app-style" rel="stylesheet" type="text/css" />
</head>

</head>

<body>

    <div class="account-pages my-5 pt-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card overflow-hidden border">
                        <div class="bg-primary">
                            <div class="text-primary text-center p-4">
                                <h5 class="text-white font-size-20">Sign Up Idofront</h5>
                                <p class="text-white-50">Daftar untuk mendapatkan akun.</p>
                                <a href="#" class="logo logo-admin">
                                    <img src="/images/logo-sm.png" height="24" alt="logo">
                                </a>
                            </div>
                        </div>

                        <div class="card-body p-4">
                            <div class="p-3">
                                <form method="POST" class="form-horizontal mt-4" action="<?php echo base_url('home/signupAuth'); ?>">

                                    <div class="form-group">
                                        <label for="username">Username</label>
                                        <input type="text" class="form-control" name="username"
                                            placeholder="Masukkan username" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="nama">Nama</label>
                                        <input type="text" class="form-control" name="nama" placeholder="Masukkan nama"
                                            required>
                                    </div>
                                    <div class="form-group">
                                        <label for="nohp">Nomor Telepon</label>
                                        <input type="number" class="form-control" name="nohp"
                                            placeholder="Masukkan nohp" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="email" class="form-control" name="email"
                                            placeholder="Masukkan email" required>
                                    </div>

                                    <div class="form-group">
                                        <label for="userpassword">Password</label>
                                        <input type="password" class="form-control" name="password"
                                            placeholder="Masukkan password" required>
                                    </div>

                                    <?php 
                                        @$pesan = session()->getFlashdata('pesan');
                                            if (isset($pesan)) {
                                                if ($pesan == 'duplicate') {
                                                    echo '<div class="alert alert-danger" role="alert">Username sudah digunakan!</div>';
                                                }
                                                else if ($pesan == 'berhasil_daftar') {
                                                    echo '<div class="alert alert-success" role="alert">Daftar Berhasil, Silahkan Login!</div>';
                                                }
                                            }
                                        ?>

                                    <div class="form-group row py-4">
                                        <div class="col-sm-12 text-right">
                                            <button class="btn btn-primary w-md waves-effect waves-light"
                                                type="submit">Sign Up</button>
                                        </div>
                                    </div>

                                </form>
                                <div class="mt-2 text-center">
                                    <p>Sudah Mempunyai Akun ? <a href="<?php echo base_url('home/login'); ?>"
                                            class="font-weight-medium text-primary">
                                            Login Sekarang </a> </p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    Admin/
    <script src="/libs/jquery/jquery.min.js"></script>
    <script src="/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/libs/metismenu/metisMenu.min.js"></script>
    <script src="/libs/simplebar/simplebar.min.js"></script>
    <script src="/libs/node-waves/waves.min.js"></script>
    <script src="/js/app.js"></script>

</body>

</html>