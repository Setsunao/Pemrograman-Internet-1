<?php

// the path you need to follow to access your file
namespace App\ThirdParty;

class FPDF {
    
    public function __construct() {
        // do your things
    }
}