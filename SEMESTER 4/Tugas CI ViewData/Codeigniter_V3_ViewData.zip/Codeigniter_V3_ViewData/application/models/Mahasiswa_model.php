<?php
    class Mahasiswa_model extends CI_Model{
        function __construct(){
            parent::__construct();
            $this->load->database();
        }

        public function getAllMahasiswa(){
            $query = $this->db->get('mahasiswa');
            return $query->result();
        }
    }
?>