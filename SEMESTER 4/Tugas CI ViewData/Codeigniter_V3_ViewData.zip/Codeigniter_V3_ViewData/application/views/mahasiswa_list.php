<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css"> 

    <title>Codeigniter UNIGA</title>
</head>
<body>

    <div class="container">
        <h1 class="page-header text-center">Belajar Framework CI [uniga]</h1>
        <div class="row">
            <div class="col-12 ">
                <a href="<?php echo base_url(); ?> index.php/mahasiswa/addnew" class="btn btn-primary">
                    <span class="glyphicon glyphicon-plus"></span> Add New
                </a><br><br>
                <table class="table table-bordered table-stripped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NAMA</th>
                            <th>NIM</th>
                            <th>JURUSAN</th>
                            <th>ALAMAT</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            foreach($result as $data){
                        ?>
                        <tr>
                            <td><?php echo $data->id; ?></td>
                            <td><?php echo $data->nama; ?></td>
                            <td><?php echo $data->nim; ?></td>
                            <td><?php echo $data->jurusan; ?></td>
                            <td><?php echo $data->alamat; ?></td>
                            <td>
                                <a href="<?php echo base_url(); ?>index.php/mahasiswa/edit/<?php echo $data->id; ?>" class="btn btn-success">
                                    <span class="glyphicon glyphicon-edit"></span> EDIT
                                </a> || 
                                <a href="<?php echo base_url() ?>index.php/mahasiswa/delete/<?php $data->id ?>" class="btn btn-danger">
                                    <span class="glyphicon glyphicon-trash"></span> DELETE
                                </a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
</body>
</html>