<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Mahasiswa_model');
    }

    public function index(){
        $data['result'] = $this->Mahasiswa_model->getAllMahasiswa();
        $this->load->view('mahasiswa_list.php', $data);
    }

}


?>