<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo base_url(); ?>bootstrap/css/bootstrap.min.css"> 

    <title>BIODATA</title>

    <style>
      .bg-grey1{
        background-color: #444444;
      }
      .bg-grey2{
        background-color: #222222;
      }
      .text-white{
        color: #f3f3f3 !important;
      }
      .rounded{
        border-radius: 20px !important;
      }
      .cover-img{
        background-image: url('<?php echo base_url() ?>img/bg.jpg'); 
        background-size: cover;
        background-position: center;
      }

    </style>


</head>
<body style="background-color: #f2f2f2;">

    <div class="wrap row m-5 p-0 bg-grey1 rounded shadow-sm">

      <div class="col-4 p-5 text-white text-center bg-grey1 rounded">
        <img src="<?php echo base_url(); ?>img/profile.png" alt="profile-img" width="150">
        <h4 class="pt-4">Muhammad Ashraf Rafsanjani</h4>
        <span>Sistem Informasi - 19510022</span>
        <br>
        <div class="py-5">
          <span>Belajar Menggunakan CodeIgniter 3 dan Bootstrap 4 . Ini adalah halaman view Biodata yang di load dari controller Biodata yang merupakan route controler utama menggantikan welcome_message default dari CodeIgniter</span>
        </div>
        
      </div>
      
      <div class="col-8 bg-grey2 rounded cover-img">
      </div>

    </div>
    
</body>
</html>