<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Mahasiswa extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Mahasiswa_model');
    }

    public function index(){
        $data['result'] = $this->Mahasiswa_model->getAllMahasiswa();
        $this->load->view('mahasiswa_list.php', $data);
    }

    public function add(){
        $this->load->view('mahasiswa_add.php');
    }

    public function insert(){
        $data['nama'] = $this->input->post('nama');
        $data['nim'] = $this->input->post('nim');
        $data['jurusan'] = $this->input->post('jurusan');
        $data['alamat'] = $this->input->post('alamat');

        $insert = $this->Mahasiswa_model->insertMahasiswa($data);
        if($insert){
            header('location:' .base_url().$this->index());
        }
    }

    public function edit($id){
        $data['mahasiswa'] = $this->Mahasiswa_model->getUserId($id);
        $this->load->view('mahasiswa_edit.php', $data);
    }

    public function update($id){
        $data['nama'] = $this->input->post('nama');
        $data['nim'] = $this->input->post('nim');
        $data['jurusan'] = $this->input->post('jurusan');
        $data['alamat'] = $this->input->post('alamat');

        $insert = $this->Mahasiswa_model->update($id, $data);
        if($insert){
            header('location:' .base_url().$this->index());
        }
    }

    public function delete($id){
        $delete = $this->Mahasiswa_model->delete($id);
        if($delete){
            header('location:' .base_url().$this->index());
        }
    }

}


?>