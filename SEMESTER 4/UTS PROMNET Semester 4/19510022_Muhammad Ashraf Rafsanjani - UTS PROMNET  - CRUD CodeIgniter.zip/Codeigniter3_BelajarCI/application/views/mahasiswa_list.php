<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo base_url('bootstrap/css/bootstrap.min.css'); ?>"> 

    <style>
        .modal {
        text-align: center;
        }

        @media screen and (min-width: 768px) { 
        .modal:before {
            display: inline-block;
            vertical-align: middle;
            content: " ";
            height: 100%;
        }
        }

        .modal-dialog {
        display: inline-block;
        text-align: left;
        vertical-align: middle;
        }
    </style>

    <title>Codeigniter UNIGA</title>
</head>
<body>

    <div class="container">
        <h1 class="page-header text-center">Belajar Framework CI [uniga]</h1>
        <div class="row">
            <div class="col-12 ">
                <a href="<?php echo site_url('mahasiswa/add'); ?>" class="btn btn-primary">
                    <span class="glyphicon glyphicon-plus"></span> Add New
                </a><br><br>
                <table class="table table-bordered table-stripped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NAMA</th>
                            <th>NIM</th>
                            <th>JURUSAN</th>
                            <th>ALAMAT</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            foreach($result as $data){
                        ?>
                        <tr>
                            <td><?php echo $data->id; ?></td>
                            <td><?php echo $data->nama; ?></td>
                            <td><?php echo $data->nim; ?></td>
                            <td><?php echo $data->jurusan; ?></td>
                            <td><?php echo $data->alamat; ?></td>
                            <td>
                                <a href="<?php echo base_url(); ?>index.php/mahasiswa/edit/<?php echo $data->id; ?>" class="btn btn-success">
                                    <span class="glyphicon glyphicon-edit"></span> EDIT
                                </a> ||

                                <a href="#" data-href="<?php echo base_url() ?>index.php/mahasiswa/delete/<?php echo $data->id ?>" data-toggle="modal" data-target="#confirm-delete" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> DELETE</a>                             

                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <h3>Hapus data?</h3
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-danger btn-ok">Delete</a>
                </div>
            </div>
        </div>
    </div>

    
    <script src="<?php echo base_url("bootstrap/js/jquery.min.js"); ?>"></script>
    <script src="<?php echo base_url("bootstrap/js/bootstrap.min.js"); ?>"></script>

    <script>
        $('#confirm-delete').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    </script>

</body>
</html>