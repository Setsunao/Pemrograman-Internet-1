<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?php echo base_url('bootstrap/css/bootstrap.min.css'); ?>"> 

    <title>Codeigniter UNIGA</title>
</head>
<body>
<div class="container">
	<h1 class="page-header text-center">Belajar Framework CI [uniga]</h1>
	<div class="row">
		<div class="col-sm-4 col-sm-offset-4">
			<h3>Tambah Data
				<span class="pull-right"><a href="<?php echo base_url(); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-arrow-left"></span> Back</a></span>
			</h3>
			<hr>
			<form method="POST" action="<?php echo site_url('mahasiswa/insert'); ?>">
				<div class="form-group">
					<label>Nama:</label>
					<input type="text" class="form-control" name="nama" required>
				</div>
				<div class="form-group">
					<label>NIM:</label>
					<input type="text" class="form-control" name="nim" required>
				</div>
				<div class="form-group">
					<label>Jurusan:</label>
					<input type="text" class="form-control" name="jurusan" required>
				</div>
				<div class="form-group">
					<label>Alamat:</label>
					<input type="text" class="form-control" name="alamat" required>
				</div>
				<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Save</button>
			</form>
		</div>
	</div>
</div>
</body>
</html>