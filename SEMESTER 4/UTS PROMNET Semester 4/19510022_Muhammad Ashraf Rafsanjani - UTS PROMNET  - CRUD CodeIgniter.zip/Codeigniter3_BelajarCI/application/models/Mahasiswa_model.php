<?php
    class Mahasiswa_model extends CI_Model{
        function __construct(){
            parent::__construct();
            $this->load->database();
        }

        public function getAllMahasiswa(){
            $query = $this->db->get('mahasiswa');
            return $query->result();
        }

        public function insertMahasiswa($data){
            return $query = $this->db->insert('mahasiswa',$data);
        }
        
        public function getUserId($id){
            $query = $this->db->get_where('mahasiswa', array('id' => $id));
            return $query->row_array();
        }
        
        public function update($id, $data){
            $query = $this->db->where('mahasiswa.id', $id);
            return $this->db->update('mahasiswa', $data);
        }
        
        public function delete($id){
            $query = $this->db->where('mahasiswa.id', $id);
            return $this->db->delete('mahasiswa');
        }


    }
?>